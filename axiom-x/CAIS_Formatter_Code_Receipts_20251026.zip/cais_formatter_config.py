#!/usr/bin/env python3
"""
CAIS Formatter Specialization - Axiom X Worker Configuration
===========================================================

Configuration for integrating CAIS formatter as a specialized worker
in the Axiom X fractal worker system.

This file defines the CAIS formatter specialization that can be spawned
by the fractal worker spawner for academic paper formatting tasks.

Author: Axiom X Integration Team
Date: October 26, 2025
"""

# CAIS Formatter Worker Specialization Configuration
CAIS_FORMATTER_CONFIG = {
    "specialization": "cais_formatter",
    "description": "CAIS Academic Paper Formatter - Converts JSON/Markdown/Text to CAIS-compliant academic papers",
    "version": "1.0.0",
    "capabilities": [
        "academic_paper_formatting",
        "style_validation",
        "citation_formatting",
        "html_reports",
        "batch_processing",
        "constitutional_ai_compliance"
    ],
    "input_formats": ["json", "markdown", "text"],
    "output_formats": ["markdown", "html", "json"],
    "worker_class": "cais_formatter_worker.CAISFormatterWorker",
    "module_path": "cais_formatter_worker",
    "dependencies": [
        "cais_formatter",
        "json",
        "pathlib",
        "html"
    ],
    "resource_requirements": {
        "cpu_cores": 1,
        "memory_gb": 2,
        "disk_space_gb": 1
    },
    "performance_metrics": {
        "avg_processing_time_seconds": 30,
        "max_concurrent_jobs": 5,
        "success_rate_target": 0.95
    },
    "constitutional_ai_compliance": {
        "satya_enabled": True,  # Truth - accurate formatting
        "asteya_enabled": True,  # Attribution - proper citations
        "ahimsa_enabled": True,  # No harm - ethical academic practices
        "validation_required": True
    },
    "quality_gates": {
        "min_compliance_score": 80.0,
        "max_style_errors": 10,
        "citation_accuracy_required": True,
        "html_report_generation": True
    },
    "integration_points": {
        "axiom_x_core": True,
        "log3_bellman_optimization": True,
        "telemetry_enabled": True,
        "sidecar_routing": True
    }
}

# Worker spawn configuration for fractal worker spawner
WORKER_SPAWN_CONFIG = {
    "worker_type": "specialized",
    "auto_scaling": {
        "min_workers": 1,
        "max_workers": 3,
        "scale_up_threshold": 0.8,  # 80% utilization
        "scale_down_threshold": 0.2,  # 20% utilization
        "cooldown_seconds": 300
    },
    "health_checks": {
        "enabled": True,
        "interval_seconds": 60,
        "timeout_seconds": 30,
        "failure_threshold": 3
    },
    "logging": {
        "level": "INFO",
        "format": "%(asctime)s - CAIS-%(name)s - %(levelname)s - %(message)s",
        "file_rotation": "daily",
        "max_files": 7
    },
    "error_handling": {
        "max_retries": 3,
        "retry_delay_seconds": 60,
        "circuit_breaker_enabled": True,
        "fallback_worker": "general_purpose"
    }
}

# Example usage configurations
EXAMPLE_CONFIGURATIONS = {
    "single_paper_formatting": {
        "input_file": "paper.json",
        "output_dir": "formatted_papers",
        "generate_html_report": True,
        "constitutional_validation": True
    },
    "batch_academic_processing": {
        "input_files": ["paper1.json", "paper2.json", "paper3.json"],
        "output_dir": "batch_formatted",
        "parallel_processing": True,
        "summary_report": True
    },
    "journal_submission_prep": {
        "input_file": "manuscript.json",
        "output_dir": "cais_submission",
        "style_validation": "strict",
        "citation_check": True,
        "final_proofread": True
    }
}

def get_worker_config() -> dict:
    """Get the complete CAIS formatter worker configuration."""
    return {
        "formatter_config": CAIS_FORMATTER_CONFIG,
        "spawn_config": WORKER_SPAWN_CONFIG,
        "examples": EXAMPLE_CONFIGURATIONS
    }

def validate_configuration() -> bool:
    """
    Validate the CAIS formatter configuration for Axiom X compatibility.

    Returns:
        True if configuration is valid, False otherwise
    """
    required_fields = [
        "specialization", "description", "capabilities", "worker_class",
        "constitutional_ai_compliance", "quality_gates"
    ]

    for field in required_fields:
        if field not in CAIS_FORMATTER_CONFIG:
            print(f"❌ Missing required field: {field}")
            return False

    # Check constitutional AI compliance
    cai = CAIS_FORMATTER_CONFIG.get("constitutional_ai_compliance", {})
    if not all([cai.get("satya_enabled"), cai.get("asteya_enabled"), cai.get("ahimsa_enabled")]):
        print("❌ Constitutional AI compliance not fully enabled")
        return False

    # Check quality gates
    qg = CAIS_FORMATTER_CONFIG.get("quality_gates", {})
    if qg.get("min_compliance_score", 0) < 80:
        print("❌ Quality gate compliance score too low")
        return False

    print("✅ CAIS formatter configuration validated for Axiom X")
    return True

if __name__ == "__main__":
    # Configuration validation
    print("🔍 Validating CAIS Formatter Configuration...")
    if validate_configuration():
        print("✅ Configuration valid - ready for Axiom X integration")

        # Display configuration summary
        config = get_worker_config()
        print("\n📋 Configuration Summary:")
        print(f"   Specialization: {config['formatter_config']['specialization']}")
        print(f"   Version: {config['formatter_config']['version']}")
        print(f"   Capabilities: {len(config['formatter_config']['capabilities'])}")
        print(f"   CAI Compliance: ✅ Enabled")
        print(f"   Quality Gates: ✅ Set")

    else:
        print("❌ Configuration validation failed")
        exit(1)