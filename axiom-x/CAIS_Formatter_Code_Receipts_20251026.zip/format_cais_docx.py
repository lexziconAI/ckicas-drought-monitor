#!/usr/bin/env python3
"""
CAIS Paper Word Document Formatter
Enhances pandoc-generated docx with proper academic formatting
"""

import docx
from docx.shared import Inches, Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE

def format_academic_document(docx_path):
    """Format the Word document with academic paper standards"""

    # Load the document
    doc = docx.Document(docx_path)

    # Set document properties
    doc.core_properties.title = "Empowering Communities: The CKICAS Framework for Adaptive, Real-Time Decision-Making in Sustainable Development"
    doc.core_properties.author = "Regan Duff"
    doc.core_properties.subject = "Complex Adaptive Systems, Intelligence Augmentation"

    # Define styles
    styles = doc.styles

    # Title style
    if 'Title' not in [s.name for s in styles]:
        title_style = styles.add_style('Title', WD_STYLE_TYPE.PARAGRAPH)
        title_style.font.size = Pt(16)
        title_style.font.bold = True
        title_style.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        title_style.paragraph_format.space_after = Pt(24)

    # Heading 1 style
    if 'Heading 1' in [s.name for s in styles]:
        h1_style = styles['Heading 1']
        h1_style.font.size = Pt(14)
        h1_style.font.bold = True
        h1_style.paragraph_format.space_before = Pt(18)
        h1_style.paragraph_format.space_after = Pt(12)

    # Heading 2 style
    if 'Heading 2' in [s.name for s in styles]:
        h2_style = styles['Heading 2']
        h2_style.font.size = Pt(12)
        h2_style.font.bold = True
        h2_style.paragraph_format.space_before = Pt(12)
        h2_style.paragraph_format.space_after = Pt(6)

    # Normal text style
    normal_style = styles['Normal']
    normal_style.font.name = 'Times New Roman'
    normal_style.font.size = Pt(12)
    normal_style.paragraph_format.line_spacing = 1.5
    normal_style.paragraph_format.space_after = Pt(6)

    # Set page margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1.25)
        section.right_margin = Inches(1.25)

    # Process paragraphs and apply formatting
    for para in doc.paragraphs:
        # Format title
        if para.text.startswith('**Empowering Communities'):
            para.style = styles['Title']

        # Format section headings
        elif para.text in ['Abstract', 'Introduction', 'CKICAS: Constitutional Knowledge-Intensive Complex Adaptive Systems',
                          'Research Methodology', 'Empirical Validation of CKICAS Propositions',
                          'Theoretical and Practical Implications of CKICAS', 'Conclusion: CKICAS as Foundation for Intelligence-Augmented Systems']:
            para.style = styles['Heading 1']

        # Format subsection headings
        elif any(para.text.startswith(prefix) for prefix in ['### ', '## ', 'The Intelligence', 'Complex Adaptive', 'Mixed-Methods', 'Proposition', 'Theoretical Advancement', 'Design Principles', 'Domain Applications', 'Significance for']):
            para.style = styles['Heading 2']

        # Clean up markdown artifacts
        if para.text.startswith('## ') or para.text.startswith('### '):
            para.text = para.text.lstrip('#').strip()
        elif para.text.startswith('**') and para.text.endswith('**'):
            para.text = para.text.strip('*')
            para.runs[0].bold = True

    # Save the formatted document
    doc.save(docx_path)
    print(f"Document formatted successfully: {docx_path}")

if __name__ == "__main__":
    docx_path = r"C:\Users\regan\OneDrive - axiomintelligence.co.nz\New Beginnings\PhD\CAIS\CAIS Updated v4 6.10.25.docx"
    format_academic_document(docx_path)