#!/usr/bin/env python3
"""
CAIS Formatter Worker - Axiom X Integration
===========================================

Specialized worker for CAIS (Communications of the Association for Information Systems)
academic paper formatting within the Axiom X infrastructure.

This worker integrates the CAIS formatter skill into Axiom X's fractal worker system,
providing automated academic paper formatting with constitutional AI compliance.

Features:
- JSON/Markdown/Text input processing
- CAIS style corrections and validation
- HTML validation reports
- Batch processing capabilities
- Constitutional AI compliance monitoring

Author: Axiom X Integration Team
Date: October 26, 2025
"""

import sys
import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

# Add the axiom-x directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from cais_formatter import CAISFormatter, ValidationReport

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CAISFormatterWorker:
    """
    Axiom X worker for CAIS academic paper formatting.

    Integrates with Axiom X's fractal worker architecture to provide
    specialized academic formatting capabilities.
    """

    def __init__(self, worker_id: str = None):
        """Initialize the CAIS formatter worker."""
        self.worker_id = worker_id or f"cais_formatter_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.formatter = CAISFormatter()
        self.stats = {
            'papers_formatted': 0,
            'total_issues_found': 0,
            'average_compliance': 0.0,
            'processing_time': 0.0
        }

        logger.info(f"CAIS Formatter Worker {self.worker_id} initialized")

    def process_paper(self, input_data: Dict[str, Any], output_dir: str = "output") -> Dict[str, Any]:
        """
        Process a single academic paper through CAIS formatting.

        Args:
            input_data: Paper data (JSON format)
            output_dir: Directory to save outputs

        Returns:
            Processing results and metadata
        """
        import time
        start_time = time.time()

        try:
            logger.info(f"Processing paper: {input_data.get('title', 'Untitled')}")

            # Format the paper
            formatted_paper, validation_report = self.formatter.format_paper(input_data)

            # Update statistics
            self.stats['papers_formatted'] += 1
            self.stats['total_issues_found'] += validation_report.total_issues

            # Save outputs
            output_path = Path(output_dir)
            output_path.mkdir(exist_ok=True)

            title_slug = self._create_title_slug(input_data.get('title', 'untitled'))
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

            # Save formatted paper
            paper_file = output_path / f"{title_slug}_formatted_{timestamp}.md"
            with open(paper_file, 'w', encoding='utf-8') as f:
                f.write(formatted_paper)

            # Save validation report as JSON
            report_file = output_path / f"{title_slug}_validation_{timestamp}.json"
            report_data = {
                'paper_title': input_data.get('title', ''),
                'processing_timestamp': timestamp,
                'compliance_score': validation_report.compliance_score,
                'total_issues': validation_report.total_issues,
                'errors': len(validation_report.errors),
                'warnings': len(validation_report.warnings),
                'suggestions': len(validation_report.suggestions),
                'issues': [
                    {
                        'line': issue.line_number,
                        'type': issue.issue_type,
                        'severity': issue.severity,
                        'original': issue.original_text,
                        'suggestion': issue.suggested_fix,
                        'explanation': issue.explanation
                    }
                    for issue in validation_report.errors + validation_report.warnings + validation_report.suggestions
                ]
            }

            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)

            # Generate HTML report
            html_report = self.formatter.generate_html_report(validation_report)
            html_file = output_path / f"{title_slug}_validation_{timestamp}.html"
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html_report)

            processing_time = time.time() - start_time
            self.stats['processing_time'] += processing_time

            # Update average compliance
            total_papers = self.stats['papers_formatted']
            self.stats['average_compliance'] = (
                (self.stats['average_compliance'] * (total_papers - 1)) +
                validation_report.compliance_score
            ) / total_papers

            result = {
                'status': 'success',
                'worker_id': self.worker_id,
                'paper_title': input_data.get('title', ''),
                'processing_time': processing_time,
                'compliance_score': validation_report.compliance_score,
                'issues_found': validation_report.total_issues,
                'output_files': {
                    'formatted_paper': str(paper_file),
                    'validation_json': str(report_file),
                    'validation_html': str(html_file)
                },
                'statistics': self.stats.copy()
            }

            logger.info(f"Successfully processed paper. Compliance: {validation_report.compliance_score:.1f}%")
            return result

        except Exception as e:
            processing_time = time.time() - start_time
            logger.error(f"Error processing paper: {e}")

            return {
                'status': 'error',
                'worker_id': self.worker_id,
                'error': str(e),
                'processing_time': processing_time
            }

    def batch_process(self, input_files: List[str], output_dir: str = "batch_output") -> Dict[str, Any]:
        """
        Process multiple papers in batch mode.

        Args:
            input_files: List of JSON file paths
            output_dir: Directory for batch outputs

        Returns:
            Batch processing results
        """
        logger.info(f"Starting batch processing of {len(input_files)} papers")

        batch_results = []
        successful = 0
        failed = 0

        for input_file in input_files:
            try:
                with open(input_file, 'r', encoding='utf-8') as f:
                    input_data = json.load(f)

                result = self.process_paper(input_data, output_dir)
                batch_results.append(result)

                if result['status'] == 'success':
                    successful += 1
                else:
                    failed += 1

            except Exception as e:
                logger.error(f"Failed to process {input_file}: {e}")
                batch_results.append({
                    'status': 'error',
                    'input_file': input_file,
                    'error': str(e)
                })
                failed += 1

        batch_summary = {
            'batch_status': 'completed',
            'total_files': len(input_files),
            'successful': successful,
            'failed': failed,
            'success_rate': successful / len(input_files) if input_files else 0,
            'average_compliance': self.stats['average_compliance'],
            'total_issues': self.stats['total_issues'],
            'results': batch_results,
            'worker_stats': self.stats.copy()
        }

        logger.info(f"Batch processing complete. Success rate: {batch_summary['success_rate']:.1%}")
        return batch_summary

    def _create_title_slug(self, title: str) -> str:
        """Create a URL-safe slug from the paper title."""
        import re
        # Remove special characters and replace spaces with underscores
        slug = re.sub(r'[^\w\s-]', '', title.lower())
        slug = re.sub(r'[\s_-]+', '_', slug)
        slug = slug.strip('_')
        return slug[:50]  # Limit length

    def get_status(self) -> Dict[str, Any]:
        """Get worker status and statistics."""
        return {
            'worker_id': self.worker_id,
            'status': 'active',
            'specialization': 'cais_formatting',
            'statistics': self.stats.copy(),
            'capabilities': [
                'json_paper_formatting',
                'markdown_conversion',
                'style_validation',
                'html_reports',
                'batch_processing',
                'constitutional_ai_compliance'
            ]
        }

def main():
    """Command-line interface for CAIS Formatter Worker."""
    import argparse

    parser = argparse.ArgumentParser(description='CAIS Formatter Worker - Axiom X Integration')
    parser.add_argument('--input', '-i', help='Input JSON file')
    parser.add_argument('--batch', '-b', nargs='+', help='Batch process multiple JSON files')
    parser.add_argument('--output-dir', '-o', default='cais_output', help='Output directory')
    parser.add_argument('--worker-id', '-w', help='Worker ID')
    parser.add_argument('--status', action='store_true', help='Show worker status')
    parser.add_argument('--test', action='store_true', help='Run self-test with sample data')

    args = parser.parse_args()

    # Initialize worker
    worker = CAISFormatterWorker(args.worker_id)

    if args.status:
        # Show worker status
        status = worker.get_status()
        print(json.dumps(status, indent=2))

    elif args.test:
        # Run self-test
        print("🧪 Running CAIS Formatter Worker self-test...")

        # Create test data
        test_paper = {
            "title": "Test Paper for CAIS Formatting",
            "authors": [{"name": "Test Author", "affiliation": "Test University"}],
            "abstract": "This paper was written to test the CAIS formatter. The study utilizes various methods to demonstrate functionality.",
            "keywords": ["test", "formatting", "cais"],
            "sections": [
                {
                    "heading": "Introduction",
                    "level": 1,
                    "content": "The field of information systems is rapidly evolving. Researchers utilize new methods to study these phenomena."
                }
            ],
            "references": [
                {
                    "type": "journal",
                    "authors": ["Test, A.", "Author, B."],
                    "year": 2023,
                    "title": "Test Article Title",
                    "journal": "Test Journal",
                    "volume": "1",
                    "issue": "1",
                    "pages": "1-10"
                }
            ]
        }

        # Process test paper
        result = worker.process_paper(test_paper, args.output_dir)

        if result['status'] == 'success':
            print("✅ Self-test PASSED")
            print(f"   Compliance Score: {result['compliance_score']:.1f}%")
            print(f"   Issues Found: {result['issues_found']}")
            print(f"   Output Files: {len(result['output_files'])}")
        else:
            print("❌ Self-test FAILED")
            print(f"   Error: {result.get('error', 'Unknown error')}")

    elif args.batch:
        # Batch processing
        print(f"📦 Starting batch processing of {len(args.batch)} files...")
        batch_result = worker.batch_process(args.batch, args.output_dir)

        print("📊 Batch Processing Complete:")
        print(f"   Total Files: {batch_result['total_files']}")
        print(f"   Successful: {batch_result['successful']}")
        print(f"   Failed: {batch_result['failed']}")
        print(".1%")

    elif args.input:
        # Single file processing
        print(f"📄 Processing single file: {args.input}")
        try:
            with open(args.input, 'r', encoding='utf-8') as f:
                input_data = json.load(f)

            result = worker.process_paper(input_data, args.output_dir)

            if result['status'] == 'success':
                print("✅ Processing successful!")
                print(f"   Title: {result['paper_title']}")
                print(f"   Compliance: {result['compliance_score']:.1f}%")
                print(f"   Processing Time: {result['processing_time']:.2f}s")
                print(f"   Output Directory: {args.output_dir}")
            else:
                print("❌ Processing failed!")
                print(f"   Error: {result.get('error', 'Unknown error')}")

        except FileNotFoundError:
            print(f"❌ Error: Input file '{args.input}' not found")
        except json.JSONDecodeError as e:
            print(f"❌ Error: Invalid JSON in input file: {e}")

    else:
        # Show help
        parser.print_help()

if __name__ == '__main__':
    main()