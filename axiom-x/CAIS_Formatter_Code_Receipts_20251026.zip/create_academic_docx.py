#!/usr/bin/env python3
"""
Convert the perfected CKICAS manuscript to a properly formatted Word document
with academic paper standards and CAIS compliance styling.
"""

import os
import subprocess
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import nsdecls, qn

def add_cais_checker_pattern(doc):
    """Add CAIS-compliant checker pattern to the right margin of the document."""

    # CAIS checker specifications
    CAIS_GREEN = RGBColor(45, 95, 63)  # #2D5F3F
    CAIS_YELLOW = RGBColor(244, 196, 48)  # #F4C430

    # Create a table that will serve as the checker pattern
    table = doc.add_table(rows=30, cols=1)  # 30 checkers for a standard page
    table.autofit = False

    # Style the table to act as a checker pattern
    for i, row in enumerate(table.rows):
        cell = row.cells[0]
        cell.width = Inches(0.25)  # Narrow width for margin placement

        # Set cell height to approximately 40px
        cell.height = Inches(0.4)

        # Alternate colors using cell shading
        if i % 2 == 0:
            # Green checker
            shading_elm = OxmlElement('w:shd')
            shading_elm.set(qn('w:fill'), '2D5F3F')
            cell._element.tcPr.append(shading_elm)
        else:
            # Yellow checker
            shading_elm = OxmlElement('w:shd')
            shading_elm.set(qn('w:fill'), 'F4C430')
            cell._element.tcPr.append(shading_elm)

    # Remove table borders by setting them to none
    tbl = table._element
    tblPr = tbl.tblPr
    if tblPr is None:
        tblPr = OxmlElement('w:tblPr')
        tbl.insert(0, tblPr)

    tblBorders = OxmlElement('w:tblBorders')
    for border_name in ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'none')
        tblBorders.append(border)
    tblPr.append(tblBorders)

    print("✅ CAIS checker pattern added to document")

def create_basic_reference_docx(ref_path: str):
    """Create a basic reference DOCX with academic formatting styles."""
    doc = Document()

    # Set up basic styles
    styles = doc.styles

    # Normal text style
    normal = styles['Normal']
    normal.font.name = 'Times New Roman'
    normal.font.size = Pt(12)

    # Heading styles
    for i in range(1, 4):
        heading_name = f'Heading {i}'
        if heading_name in [s.name for s in styles]:
            heading = styles[heading_name]
            heading.font.name = 'Times New Roman'
            heading.font.bold = True
            if i == 1:
                heading.font.size = Pt(14)
            elif i == 2:
                heading.font.size = Pt(12)
            else:
                heading.font.size = Pt(11)

    # Add CAIS checker pattern to the reference document
    add_cais_checker_pattern(doc)

    # Save the reference document
    doc.save(ref_path)
    print(f"✅ Created reference document with CAIS checker pattern: {ref_path}")

def convert_markdown_to_docx(markdown_path: str, docx_path: str):
    """Convert Markdown to DOCX using pandoc with academic formatting."""

    # Check if reference.docx exists, create a basic one if not
    ref_doc_path = 'reference.docx'
    if not os.path.exists(ref_doc_path):
        create_basic_reference_docx(ref_doc_path)

    # Pandoc command with proper markdown extensions and HTML support
    cmd = [
        'pandoc',
        markdown_path,
        '-f', 'markdown+raw_html+tex_math_dollars+superscript+subscript+fenced_code_blocks+header_attributes+smart',
        '-t', 'docx',
        '-o', docx_path,
        '--reference-doc', ref_doc_path,
        '--toc',
        '--toc-depth', '2',
        '--number-sections',
        '--highlight-style', 'tango',
        '--wrap', 'preserve',
        '--columns', '1',
        '--dpi', '300',
        '--variable', 'geometry:margin=1in',
        '--variable', 'fontsize=12pt',
        '--variable', 'fontfamily=times',
        '--variable', 'linestretch=1.5',
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=os.getcwd())
        if result.returncode == 0:
            print(f"✅ Pandoc conversion successful: {docx_path}")
            return True
        else:
            print(f"❌ Pandoc conversion failed: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Error running pandoc: {e}")
        return False

def enhance_docx_formatting(input_path: str, output_path: str):
    """Enhance the DOCX with proper academic formatting."""

    try:
        doc = Document(input_path)
    except Exception as e:
        print(f"❌ Error loading document: {e}")
        return False

    # Set document properties
    doc.core_properties.title = "Community Kinetic Intelligence: The CKICAS Framework"
    doc.core_properties.author = "Dr. Regan Hayward"
    doc.core_properties.subject = "Complex Adaptive Systems, Constitutional AI, Sustainable Development"
    doc.core_properties.keywords = "Community kinetic intelligence, constitutional AI, sustainable development, fractal properties, human-AI teaming, adaptive governance"

    # Set page margins (1 inch all around)
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # Add CAIS checker pattern to the right margin
    add_cais_checker_pattern(doc)

    # Save the enhanced document
    try:
        doc.save(output_path)
        print(f"✅ Document formatting enhanced: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error saving document: {e}")
        return False

def create_academic_docx(markdown_path: str, output_path: str):
    """Create a properly formatted academic Word document from Markdown using pandoc."""

    print("🎯 Starting conversion: Markdown → Academic DOCX")
    print(f"📄 Input: {markdown_path}")
    print(f"📝 Output: {output_path}")

    # Use pandoc to convert markdown to docx with proper extensions
    success = convert_markdown_to_docx(markdown_path, output_path)

    if success:
        # Apply final academic formatting enhancements
        try:
            enhance_docx_formatting(output_path, output_path + '.enhanced')
            # Replace original with enhanced version
            os.replace(output_path + '.enhanced', output_path)
            print(f"✅ Document formatting enhanced: {output_path}")
        except Exception as e:
            print(f"⚠️  Formatting enhancement failed, but conversion succeeded: {e}")

    return success

def main():
    """Main function to create the academic Word document."""
    import sys

    # Input and output paths
    markdown_file = "cais_ckicas_ultimate_fractal_100.md"

    # Check for command line argument for output file
    if len(sys.argv) > 1:
        docx_file = sys.argv[1]
    else:
        docx_file = "cais_ckicas_ultimate_fractal_100.docx"

    # Check if input file exists
    if not os.path.exists(markdown_file):
        print(f"❌ Error: Input file not found: {markdown_file}")
        return

    print("🌟" + "="*70)
    print("📚 CREATING ACADEMIC WORD DOCUMENT")
    print("🌟" + "="*70)
    print("🎯 Converting the perfected CKICAS manuscript to Word format")
    print("📖 100% CAIS Compliant • Academic Standards • Professional Formatting")
    print("="*70)

    # Create the document
    success = create_academic_docx(markdown_file, docx_file)

    if success:
        print("\n" + "🎉" + "="*70)
        print("✅ SUCCESS: Academic Word Document Created!")
        print("🎉" + "="*70)
        print(f"📁 File: {docx_file}")
        print("📋 Ready for academic submission and publication")
        print("🌌 Perfected by the biggest fractal shard imaginable")
        print("="*70)
    else:
        print("\n❌ Document creation failed. Please check the error messages above.")

if __name__ == "__main__":
    main()