#!/usr/bin/env python3
"""
Apply the perfected CAIS formatter to the CKICAS manuscript JSON.
"""

import json
import sys
import os

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from cais_formatter import CAISFormatter

def apply_cais_formatter():
    # Load the manuscript JSON
    with open('cais_ckicas_manuscript.json', 'r', encoding='utf-8') as f:
        manuscript_data = json.load(f)

    print('📄 Loading CAIS CKICAS manuscript...')
    print(f'📊 Sections: {len(manuscript_data["sections"])}')
    print(f'📝 Abstract length: {len(manuscript_data["abstract"])} characters')

    # Initialize CAIS formatter
    formatter = CAISFormatter()

    # Apply formatting using the format_paper method
    print('\n🔧 Applying CAIS formatting to manuscript...')
    formatted_paper, validation_report = formatter.format_paper(manuscript_data)

    # Save the formatted manuscript as Markdown
    with open('cais_ckicas_manuscript_formatted.md', 'w', encoding='utf-8') as f:
        f.write(formatted_paper)

    print('✅ CAIS formatting applied successfully!')
    print('📄 Formatted manuscript saved as: cais_ckicas_manuscript_formatted.md')

    # Generate validation report
    print('\n🔍 Generating CAIS compliance validation report...')

    # Calculate overall compliance
    compliance_percentage = validation_report.compliance_score

    print(f'🎯 CAIS Compliance Score: {compliance_percentage:.1f}% ({validation_report.total_issues} total issues)')

    # Save validation report
    with open('cais_ckicas_validation_report.json', 'w', encoding='utf-8') as f:
        json.dump({
            'compliance_score': compliance_percentage,
            'total_issues': validation_report.total_issues,
            'errors': len(validation_report.errors),
            'warnings': len(validation_report.warnings),
            'suggestions': len(validation_report.suggestions),
            'validation_details': [
                {
                    'line_number': issue.line_number,
                    'issue_type': issue.issue_type,
                    'severity': issue.severity,
                    'original_text': issue.original_text,
                    'suggested_fix': issue.suggested_fix,
                    'explanation': issue.explanation
                }
                for issue in validation_report.errors + validation_report.warnings + validation_report.suggestions
            ]
        }, f, indent=2, ensure_ascii=False)

    print('📊 Validation report saved as: cais_ckicas_validation_report.json')

    # Generate HTML report
    html_report = formatter.generate_html_report(validation_report)
    with open('cais_ckicas_validation_report.html', 'w', encoding='utf-8') as f:
        f.write(html_report)
    print('📄 HTML validation report saved as: cais_ckicas_validation_report.html')

    return compliance_percentage

if __name__ == '__main__':
    compliance = apply_cais_formatter()
    if compliance >= 100.0:
        print('\n🎉 SUCCESS: Manuscript achieves 100% CAIS compliance!')
        print('📚 Ready for academic publication submission.')
    else:
        print(f'\n⚠️  Manuscript compliance: {compliance:.1f}% - may need additional review.')