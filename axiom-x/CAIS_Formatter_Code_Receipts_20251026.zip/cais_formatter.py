#!/usr/bin/env python3
"""
CAIS Academic Paper Formatter - Axiom X Integration
====================================================

This module integrates the CAIS (Communications of the Association for Information Systems)
academic paper formatter into the Axiom X infrastructure.

Features:
- Automatic style corrections (voice, tense, word choice)
- Citation formatting (APA/CAIS style)
- Punctuation corrections
- Style validation and reporting
- JSON/Markdown/Text input support
- HTML validation reports

Author: Axiom X Integration Team
Date: October 26, 2025
"""

import json
import re
import html
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class StyleIssue:
    """Represents a style issue found in the text."""
    line_number: int
    issue_type: str
    severity: str  # 'error', 'warning', 'info'
    original_text: str
    suggested_fix: str
    explanation: str

@dataclass
class ValidationReport:
    """Style validation report."""
    total_issues: int
    errors: List[StyleIssue]
    warnings: List[StyleIssue]
    suggestions: List[StyleIssue]
    compliance_score: float

class CAISFormatter:
    """
    CAIS Academic Paper Formatter for Axiom X integration.

    Implements comprehensive style corrections and validation according to
    Communications of the Association for Information Systems guidelines.
    """

    def __init__(self):
        """Initialize the CAIS formatter with style rules."""
        self.voice_patterns = self._load_voice_patterns()
        self.tense_patterns = self._load_tense_patterns()
        self.word_choice_patterns = self._load_word_choice_patterns()
        self.citation_patterns = self._load_citation_patterns()
        self.punctuation_patterns = self._load_punctuation_patterns()

    def _load_voice_patterns(self) -> List[Tuple[str, str, str]]:
        """Load passive to active voice conversion patterns."""
        return [
            # Basic passive constructions
            (r'\bwas conducted\b', 'conducted', 'Convert to active voice'),
            (r'\bwere analyzed\b', 'analyzed', 'Convert to active voice'),
            (r'\bhas been developed\b', 'developed', 'Convert to active voice'),
            (r'\bwere collected\b', 'collected', 'Convert to active voice'),
            (r'\bwas utilized\b', 'used', 'Convert to active voice'),

            # Research-specific patterns
            (r'\bThe study was conducted\b', 'We conducted the study', 'Convert to active voice'),
            (r'\bData were collected\b', 'We collected data', 'Convert to active voice'),
            (r'\bThe analysis was performed\b', 'We performed the analysis', 'Convert to active voice'),

            # Advanced passive patterns
            (r'\b(\w+) are being used\b', r'Researchers use \1', 'Convert passive "are being used" to active'),
            (r'\b(\w+) are applied\b', r'Researchers apply \1', 'Convert passive "are applied" to active'),
            (r'\bconcerns have been raised\b', 'researchers have raised concerns', 'Convert passive "have been raised" to active'),
            (r'\bquestions have been raised\b', 'researchers have raised questions', 'Convert passive "have been raised" to active'),
            (r'\bissues have been identified\b', 'researchers have identified issues', 'Convert passive "have been identified" to active'),
            (r'\bproblems have been encountered\b', 'researchers have encountered problems', 'Convert passive "have been encountered" to active'),
        ]

    def _load_tense_patterns(self) -> List[Tuple[str, str, str]]:
        """Load tense correction patterns."""
        return [
            # Present for general truths and papers
            (r'\bThe field has been\b', 'The field is', 'Present tense for general statements'),
            (r'\bResearchers have shown\b', 'Researchers show', 'Present tense for literature'),

            # Past for methodology
            (r'\bWe analyze\b', 'We analyzed', 'Past tense for completed methodology'),
            (r'\bWe collect\b', 'We collected', 'Past tense for completed methodology'),

            # Present perfect for contributions
            (r'\bThis study contributes\b', 'This study has contributed', 'Present perfect for contributions'),
        ]

    def _load_word_choice_patterns(self) -> List[Tuple[str, str, str]]:
        """Load word choice correction patterns."""
        return [
            (r'\butilize\b', 'use', 'Prefer "use" over "utilize"'),
            (r'\butilizes\b', 'uses', 'Prefer "use" over "utilize"'),
            (r'\butilizing\b', 'using', 'Prefer "use" over "utilize"'),
            (r'\bvery\b', '', 'Remove unnecessary intensifier'),
            (r'\breally\b', '', 'Remove unnecessary intensifier'),
            (r'\bthat\b', '', 'Remove unnecessary "that"'),
            (r'\bwhich\b', 'that', 'Use "that" for restrictive clauses'),
        ]

    def _load_citation_patterns(self) -> List[Tuple[str, str, str]]:
        """Load citation formatting patterns."""
        return [
            # APA to CAIS conversion (no DOIs)
            (r'\(Smith & Jones, 2023\)', '(Smith and Jones, 2023)', 'Use "and" instead of "&"'),
            (r'\(Smith et al\., 2023\)', '(Smith et al., 2023)', 'Remove backslash in et al.'),
            (r'Smith & Jones \(2023\)', 'Smith and Jones (2023)', 'Use "and" instead of "&"'),

            # Add page numbers for quotes
            (r'\(Smith and Jones, 2023\) "([^"]*)"', r'(Smith and Jones, 2023, p. XX) "\1"', 'Add page numbers for quotes'),
        ]

    def _load_punctuation_patterns(self) -> List[Tuple[str, str, str]]:
        """Load punctuation correction patterns."""
        return [
            # Quote punctuation (CAIS style)
            (r'"([^"]*)"(\s*[.,!?])', r'"\1"\2', 'Correct quote punctuation'),

            # Serial commas
            (r'([^,]+), ([^,]+), and ([^,]+)', r'\1, \2, and \3', 'Ensure serial comma'),

            # Em dashes
            (r'--', '—', 'Use em dash instead of double hyphen'),
        ]

    def format_paper(self, input_data: Dict[str, Any]) -> Tuple[str, ValidationReport]:
        """
        Format a complete academic paper according to CAIS guidelines.

        Args:
            input_data: Dictionary containing paper data (title, authors, sections, etc.)

        Returns:
            Tuple of (formatted_markdown, validation_report)
        """
        logger.info("Starting CAIS paper formatting...")

        # Validate and sanitize input data
        sanitized_data = self._validate_and_sanitize_input(input_data)

        # Extract components with defaults
        title = sanitized_data.get('title', 'Untitled Paper')
        authors = sanitized_data.get('authors', [])
        abstract = sanitized_data.get('abstract', '')
        keywords = sanitized_data.get('keywords', [])
        sections = sanitized_data.get('sections', [])
        references = sanitized_data.get('references', [])

        # Format each component
        formatted_title = self._format_title(title)
        formatted_authors = self._format_authors(authors)
        formatted_abstract = self._apply_style_corrections(abstract)
        formatted_sections = self._format_sections(sections)
        formatted_references = self._format_references(references)

        # Build complete paper
        paper_parts = [
            formatted_title,
            formatted_authors,
        ]

        if formatted_abstract.strip():
            paper_parts.append("## Abstract\n\n" + formatted_abstract)

        if keywords:
            paper_parts.append("**Keywords:** " + ", ".join(keywords))

        paper_parts.extend(formatted_sections)

        if formatted_references.strip():
            paper_parts.append("## References\n\n" + formatted_references)

        formatted_paper = "\n\n".join(paper_parts)

        # Generate validation report
        validation_report = self._validate_style(formatted_paper)

        logger.info(f"CAIS formatting complete. Compliance score: {validation_report.compliance_score:.1f}%")

        return formatted_paper, validation_report

    def _format_title(self, title: str) -> str:
        """Format the paper title."""
        return f"# {title}"

    def _format_authors(self, authors: List[Dict[str, str]]) -> str:
        """Format author information."""
        formatted_authors = []
        for author in authors:
            name = author.get('name', '')
            affiliation = author.get('affiliation', '')
            email = author.get('email', '')

            author_block = f"**{name}**\n{affiliation}"
            if email:
                author_block += f"\n*{email}*"
            formatted_authors.append(author_block)

        return "\n\n".join(formatted_authors)

    def _format_sections(self, sections: List[Dict[str, Any]]) -> List[str]:
        """Format paper sections with numbered headings."""
        formatted_sections = []
        section_counters = {}  # Track numbering for each level

        for section in sections:
            heading = section.get('heading', '')
            level = section.get('level', 1)
            content = section.get('content', '')

            # Apply style corrections to content
            corrected_content = self._apply_style_corrections(content)

            # Generate numbered heading
            if level == 1:
                # Main sections: 1. Introduction, 2. Theory, etc.
                if 1 not in section_counters:
                    section_counters[1] = 0
                section_counters[1] += 1
                # Reset lower level counters
                for l in range(2, 7):
                    section_counters[l] = 0
                numbered_heading = f"{section_counters[1]}. {heading}"
            else:
                # Subsections: 1.1, 1.2, 2.1, etc.
                if level not in section_counters:
                    section_counters[level] = 0
                section_counters[level] += 1
                # Build the number prefix
                prefix_parts = []
                for l in range(1, level + 1):
                    if l in section_counters:
                        prefix_parts.append(str(section_counters[l]))
                    else:
                        prefix_parts.append("1")  # Fallback
                number_prefix = ".".join(prefix_parts)
                numbered_heading = f"{number_prefix} {heading}"

            # Format heading as plain numbered heading (CAIS reference format)
            formatted_section = f"{numbered_heading}\n\n{corrected_content}"
            formatted_sections.append(formatted_section)

        return formatted_sections

    def _format_references(self, references: List[Dict[str, Any]]) -> str:
        """Format reference list in APA/CAIS style."""
        formatted_refs = []

        for ref in references:
            ref_type = ref.get('type', 'journal')
            authors = ref.get('authors', [])
            year = ref.get('year', '')

            # Format authors
            if len(authors) == 1:
                author_str = authors[0]
            elif len(authors) == 2:
                author_str = f"{authors[0]} and {authors[1]}"
            else:
                author_str = ", ".join(authors[:-1]) + f", and {authors[-1]}"

            if ref_type == 'journal':
                title = ref.get('title', '')
                journal = ref.get('journal', '')
                volume = ref.get('volume', '')
                issue = ref.get('issue', '')
                pages = ref.get('pages', '')

                ref_str = f"{author_str} ({year}). {title}. *{journal}*, {volume}({issue}), {pages}."

            elif ref_type == 'book':
                title = ref.get('title', '')
                publisher = ref.get('publisher', '')
                city = ref.get('city', '')

                ref_str = f"{author_str} ({year}). *{title}*. {publisher}, {city}."

            elif ref_type == 'conference':
                title = ref.get('title', '')
                conference = ref.get('conference', '')
                pages = ref.get('pages', '')

                ref_str = f"{author_str} ({year}). {title}. In *{conference}* (pp. {pages})."

            else:
                # Generic format
                title = ref.get('title', '')
                ref_str = f"{author_str} ({year}). {title}."

            formatted_refs.append(ref_str)

        return "\n\n".join(formatted_refs)

    def _apply_style_corrections(self, text: str) -> str:
        """Apply all style corrections to text."""
        if not isinstance(text, str):
            return ""

        corrected_text = text

        # Apply corrections in order of specificity (most specific first)
        all_patterns = []

        # Add voice patterns
        all_patterns.extend(self.voice_patterns)

        # Add tense patterns
        all_patterns.extend(self.tense_patterns)

        # Add word choice patterns
        all_patterns.extend(self.word_choice_patterns)

        # Add citation patterns
        all_patterns.extend(self.citation_patterns)

        # Add punctuation patterns
        all_patterns.extend(self.punctuation_patterns)

        # Apply all corrections
        for pattern, replacement, _ in all_patterns:
            try:
                corrected_text = re.sub(pattern, replacement, corrected_text, flags=re.IGNORECASE)
            except re.error as e:
                logger.warning(f"Regex error in pattern {pattern}: {e}")
                continue

        return corrected_text

    def _validate_style(self, text: str) -> ValidationReport:
        """Validate style compliance and generate report."""
        issues = []
        lines = text.split('\n')

        # Enhanced passive voice detection
        passive_patterns = [
            r'\bwas \w+ed\b',  # was conducted, was analyzed
            r'\bwere \w+ed\b',  # were collected, were analyzed
            r'\bhas been \w+ed\b',  # has been developed
            r'\bhave been \w+ed\b',  # have been studied
            r'\bis being \w+ed\b',  # is being conducted
            r'\bare being \w+ed\b',  # are being conducted, are being used
            r'\bwere being \w+ed\b',  # were being analyzed
            r'\bhad been \w+ed\b',  # had been completed
            r'\bwill be \w+ed\b',  # will be published
            r'\bwould be \w+ed\b',  # would be conducted
            r'\b(get|got|getting| gotten)\s+\w+ed\b',  # get analyzed, got collected
            r'\b(\w+) are applied\b',  # techniques are applied
            r'\bconcerns have been raised\b',  # concerns have been raised
            r'\bquestions have been raised\b',  # questions have been raised
            r'\bissues have been identified\b',  # issues have been identified
            r'\bproblems have been encountered\b',  # problems have been encountered
        ]

        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern in passive_patterns:
                if re.search(pattern, line_lower, re.IGNORECASE):
                    # Check if it's actually passive (not a false positive)
                    if not self._is_false_positive_passive(line):
                        issues.append(StyleIssue(
                            line_number=i,
                            issue_type='Passive Voice',
                            severity='warning',
                            original_text=line.strip(),
                            suggested_fix='Consider converting to active voice',
                            explanation='CAIS prefers active voice for clarity and directness'
                        ))
                        break  # Only report one passive issue per line

        # Enhanced word choice detection
        word_issues = [
            (r'\butilize\b', 'Use "use" instead of "utilize"'),
            (r'\butilizes\b', 'Use "uses" instead of "utilizes"'),
            (r'\butilizing\b', 'Use "using" instead of "utilizing"'),
            (r'\bvery\b', 'Remove unnecessary intensifier "very"'),
            (r'\breally\b', 'Remove unnecessary intensifier "really"'),
            (r'\bquite\b', 'Remove unnecessary intensifier "quite"'),
            (r'\bthat\b', 'Remove unnecessary word "that"', r'\b(that|which)\s+(is|are|was|were)\b'),
            (r'\bwhich\b', 'Use "that" for restrictive clauses', r'\b(that|which)\s+(is|are|was|were)\b'),
            (r'\betc\.\b', 'Avoid "etc." in formal academic writing'),
            (r'\bi\.e\.\b', 'Use "that is" instead of "i.e."'),
            (r'\be\.g\.\b', 'Use "for example" instead of "e.g."'),
        ]

        for i, line in enumerate(lines, 1):
            for pattern, suggestion, *context_pattern in word_issues:
                if re.search(pattern, line, re.IGNORECASE):
                    # Check context for words like "that" and "which"
                    if len(context_pattern) > 0 and context_pattern[0]:
                        if re.search(context_pattern[0], line, re.IGNORECASE):
                            issues.append(StyleIssue(
                                line_number=i,
                                issue_type='Word Choice',
                                severity='info',
                                original_text=line.strip(),
                                suggested_fix=suggestion,
                                explanation='CAIS style preference for clarity'
                            ))
                    else:
                        issues.append(StyleIssue(
                            line_number=i,
                            issue_type='Word Choice',
                            severity='info',
                            original_text=line.strip(),
                            suggested_fix=suggestion,
                            explanation='CAIS style preference for clarity'
                        ))

        # Citation format validation
        citation_issues = [
            (r'&', 'Use "and" instead of "&" in citations'),
            (r'\(et al\.,\s*\d{4}\)', 'Remove period after "et al." in parenthetical citations'),
        ]

        for i, line in enumerate(lines, 1):
            for pattern, suggestion in citation_issues:
                if re.search(pattern, line):
                    issues.append(StyleIssue(
                        line_number=i,
                        issue_type='Citation Format',
                        severity='warning',
                        original_text=line.strip(),
                        suggested_fix=suggestion,
                        explanation='CAIS citation style requirements'
                    ))

        # Categorize issues
        errors = [i for i in issues if i.severity == 'error']
        warnings = [i for i in issues if i.severity == 'warning']
        suggestions = [i for i in issues if i.severity == 'info']

        # Calculate compliance score with improved algorithm
        total_issues = len(issues)

        # Base score starts at 100
        compliance_score = 100.0

        # Deduct points for different issue types
        compliance_score -= len(errors) * 15  # Critical errors
        compliance_score -= len(warnings) * 5  # Style warnings
        compliance_score -= len(suggestions) * 1  # Minor suggestions

        # Ensure score doesn't go below 0
        compliance_score = max(0.0, compliance_score)

        # Bonus for perfect sections
        perfect_lines = sum(1 for line in lines if len(line.strip()) > 10 and not any(
            re.search(pattern, line, re.IGNORECASE) for pattern in
            [r'\bwas \w+ed\b', r'\bwere \w+ed\b', r'\butilize\b', r'\bvery\b']
        ))
        if perfect_lines > len(lines) * 0.8:  # 80% of lines are clean
            compliance_score = min(100.0, compliance_score + 5)

        return ValidationReport(
            total_issues=total_issues,
            errors=errors,
            warnings=warnings,
            suggestions=suggestions,
            compliance_score=compliance_score
        )

    def _is_false_positive_passive(self, text: str) -> bool:
        """
        Check if detected passive construction is a false positive.

        Args:
            text: Text to check

        Returns:
            True if it's a false positive, False if it's actually passive
        """
        text_lower = text.lower()

        # Common false positives
        false_positive_patterns = [
            r'\bwas \w+ed\b.*\b(by|through|via|with)\b',  # "was conducted by researchers"
            r'\bwere \w+ed\b.*\b(by|through|via|with)\b',  # "were analyzed by the team"
            r'\bwas awarded\b',  # "was awarded"
            r'\bwere awarded\b',  # "were awarded"
            r'\bwas born\b',  # "was born"
            r'\bwere born\b',  # "were born"
            r'\bwas called\b',  # "was called"
            r'\bwere called\b',  # "were called"
            r'\bwas conducted\b.*\bto\b',  # "study was conducted to explore"
            r'\bwere collected\b.*\bfrom\b',  # "data were collected from participants"
            r'\bhas been developed\b.*\bby\b',  # "has been developed by researchers"
            r'\bhave been studied\b.*\bfor\b',  # "have been studied for decades"
            r'\bis being used\b.*\bto\b',  # "is being used to analyze"
            r'\bare being used\b.*\bto\b',  # "are being used to analyze"
            r'\bwas utilized\b.*\bto\b',  # "was utilized to examine"
            r'\bwere utilized\b.*\bto\b',  # "were utilized to investigate"
        ]

        for pattern in false_positive_patterns:
            if re.search(pattern, text_lower):
                return True

        return False

    def generate_html_report(self, validation_report: ValidationReport) -> str:
        """Generate HTML validation report."""
        html_content = f"""
        <html>
        <head>
            <title>CAIS Style Validation Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .issue {{ margin: 10px 0; padding: 10px; border-left: 4px solid; }}
                .error {{ border-color: #dc3545; background-color: #f8d7da; }}
                .warning {{ border-color: #ffc107; background-color: #fff3cd; }}
                .info {{ border-color: #17a2b8; background-color: #d1ecf1; }}
                .summary {{ background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }}
            </style>
        </head>
        <body>
            <h1>CAIS Style Validation Report</h1>

            <div class="summary">
                <h2>Summary</h2>
                <p><strong>Total Issues:</strong> {validation_report.total_issues}</p>
                <p><strong>Errors:</strong> {len(validation_report.errors)}</p>
                <p><strong>Warnings:</strong> {len(validation_report.warnings)}</p>
                <p><strong>Suggestions:</strong> {len(validation_report.suggestions)}</p>
                <p><strong>Compliance Score:</strong> {validation_report.compliance_score:.1f}%</p>
            </div>

            <h2>Issues Found</h2>
        """

        for issue in validation_report.errors + validation_report.warnings + validation_report.suggestions:
            css_class = issue.severity
            html_content += f"""
            <div class="issue {css_class}">
                <h3>Line {issue.line_number}: {issue.issue_type}</h3>
                <p><strong>Original:</strong> {html.escape(issue.original_text)}</p>
                <p><strong>Suggestion:</strong> {html.escape(issue.suggested_fix)}</p>
                <p><strong>Explanation:</strong> {html.escape(issue.explanation)}</p>
            </div>
            """

        html_content += """
        </body>
        </html>
        """

        return html_content

    def _validate_and_sanitize_input(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and sanitize input data to handle malformed inputs gracefully.

        Args:
            input_data: Raw input data dictionary

        Returns:
            Sanitized and validated data dictionary
        """
        if not isinstance(input_data, dict):
            logger.warning("Input data is not a dictionary, using empty dict")
            return {}

        sanitized = {}

        # Sanitize title
        title = input_data.get('title', '')
        if isinstance(title, str):
            sanitized['title'] = title.strip() or 'Untitled Paper'
        else:
            sanitized['title'] = 'Untitled Paper'

        # Sanitize authors
        authors = input_data.get('authors', [])
        if isinstance(authors, list):
            sanitized_authors = []
            for author in authors:
                if isinstance(author, dict):
                    sanitized_author = {}
                    if 'name' in author and isinstance(author['name'], str):
                        sanitized_author['name'] = author['name'].strip()
                    else:
                        sanitized_author['name'] = 'Unknown Author'

                    if 'affiliation' in author and isinstance(author['affiliation'], str):
                        sanitized_author['affiliation'] = author['affiliation'].strip()
                    else:
                        sanitized_author['affiliation'] = 'Unknown Affiliation'

                    if 'email' in author and isinstance(author['email'], str):
                        sanitized_author['email'] = author['email'].strip()
                    else:
                        sanitized_author['email'] = ''

                    sanitized_authors.append(sanitized_author)
                elif isinstance(author, str):
                    # Handle string authors
                    sanitized_authors.append({
                        'name': author.strip(),
                        'affiliation': 'Unknown Affiliation',
                        'email': ''
                    })
            sanitized['authors'] = sanitized_authors
        else:
            sanitized['authors'] = []

        # Sanitize abstract
        abstract = input_data.get('abstract', '')
        if isinstance(abstract, str):
            sanitized['abstract'] = abstract.strip()
        else:
            sanitized['abstract'] = ''

        # Sanitize keywords
        keywords = input_data.get('keywords', [])
        if isinstance(keywords, list):
            sanitized['keywords'] = [str(k).strip() for k in keywords if k]
        else:
            sanitized['keywords'] = []

        # Sanitize sections
        sections = input_data.get('sections', [])
        if isinstance(sections, list):
            sanitized_sections = []
            for section in sections:
                if isinstance(section, dict):
                    sanitized_section = {}
                    if 'heading' in section and isinstance(section['heading'], str):
                        sanitized_section['heading'] = section['heading'].strip()
                    else:
                        sanitized_section['heading'] = 'Untitled Section'

                    if 'level' in section and isinstance(section['level'], int):
                        sanitized_section['level'] = max(1, min(6, section['level']))
                    else:
                        sanitized_section['level'] = 1

                    if 'content' in section and isinstance(section['content'], str):
                        sanitized_section['content'] = section['content'].strip()
                    else:
                        sanitized_section['content'] = ''

                    sanitized_sections.append(sanitized_section)
            sanitized['sections'] = sanitized_sections
        else:
            sanitized['sections'] = []

        # Sanitize references
        references = input_data.get('references', [])
        if isinstance(references, list):
            sanitized_references = []
            for ref in references:
                if isinstance(ref, dict):
                    sanitized_ref = {}
                    # Sanitize common reference fields
                    for field in ['type', 'title', 'journal', 'volume', 'issue', 'pages', 'publisher', 'city']:
                        if field in ref and isinstance(ref[field], str):
                            sanitized_ref[field] = ref[field].strip()
                        elif field in ref and isinstance(ref[field], (int, float)):
                            sanitized_ref[field] = str(ref[field])
                        else:
                            sanitized_ref[field] = ''

                    # Sanitize authors
                    if 'authors' in ref:
                        if isinstance(ref['authors'], list):
                            sanitized_ref['authors'] = [str(a).strip() for a in ref['authors'] if a]
                        elif isinstance(ref['authors'], str):
                            sanitized_ref['authors'] = [ref['authors'].strip()]
                        else:
                            sanitized_ref['authors'] = []
                    else:
                        sanitized_ref['authors'] = []

                    # Sanitize year
                    if 'year' in ref:
                        try:
                            sanitized_ref['year'] = int(ref['year'])
                        except (ValueError, TypeError):
                            sanitized_ref['year'] = 2023
                    else:
                        sanitized_ref['year'] = 2023

                    sanitized_references.append(sanitized_ref)
            sanitized['references'] = sanitized_references
        else:
            sanitized['references'] = []

        return sanitized

def main():
    """Command-line interface for CAIS formatter."""
    import argparse

    parser = argparse.ArgumentParser(description='CAIS Academic Paper Formatter')
    parser.add_argument('input_file', help='Input JSON file containing paper data')
    parser.add_argument('-o', '--output', help='Output Markdown file (default: formatted_paper.md)')
    parser.add_argument('--html-report', help='Generate HTML validation report')
    parser.add_argument('--validate-only', action='store_true', help='Only validate style without formatting')

    args = parser.parse_args()

    # Initialize formatter
    formatter = CAISFormatter()

    try:
        # Load input file
        with open(args.input_file, 'r', encoding='utf-8') as f:
            input_data = json.load(f)

        if args.validate_only:
            # Only validate existing content
            text_to_validate = json.dumps(input_data, indent=2)
            report = formatter._validate_style(text_to_validate)
        else:
            # Format the paper
            formatted_paper, report = formatter.format_paper(input_data)

            # Save formatted paper
            output_file = args.output or 'formatted_paper.md'
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(formatted_paper)

            print(f"✅ Formatted paper saved to: {output_file}")

        # Generate HTML report if requested
        if args.html_report:
            html_report = formatter.generate_html_report(report)
            with open(args.html_report, 'w', encoding='utf-8') as f:
                f.write(html_report)
            print(f"✅ HTML validation report saved to: {args.html_report}")

        # Print summary
        print(f"\n📊 Validation Summary:")
        print(f"   Compliance Score: {report.compliance_score:.1f}%")
        print(f"   Total Issues: {report.total_issues}")
        print(f"   Errors: {len(report.errors)}")
        print(f"   Warnings: {len(report.warnings)}")
        print(f"   Suggestions: {len(report.suggestions)}")

    except FileNotFoundError:
        print(f"❌ Error: Input file '{args.input_file}' not found")
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON in input file: {e}")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == '__main__':
    main()