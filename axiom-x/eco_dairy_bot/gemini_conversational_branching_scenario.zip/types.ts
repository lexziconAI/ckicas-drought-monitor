
export interface Branch {
  id: string;
  title: string;
  prompt: string;
}

export interface Scene {
  id: string;
  title: string;
  baseImage: string;
  narrative: string;
  branches: Branch[];
}

export interface BranchingScenarioReceipt {
  id: string;
  timestamp: string;
  scenario: {
    type: string;
    branch_id: string;
    depth: number;
    parent_branch?: string;
  };
  execution: {
    parallel_operations: number;
    wall_clock_ms: number;
    models_used: Array<{ model: string; role: string }>;
  };
  constitutional: {
    yama_principles: {
      satya: { checked: boolean; passed: boolean };
      asteya: { checked: boolean; passed: boolean };
      ahimsa: { checked: boolean; passed: boolean };
      brahmacharya: { checked: boolean; passed: boolean };
    },
    embedding_placeholder: string;
  };
  quality: {
    narrative_coherence: number;
    visual_alignment: number;
    voice_naturalness: number;
  };
  outcome: {
    branch_selected?: string;
    questions_asked: number;
  };
  signature: string;
}
