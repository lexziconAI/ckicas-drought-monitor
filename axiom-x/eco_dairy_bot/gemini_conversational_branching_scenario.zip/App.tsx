import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Scene, Branch, BranchingScenarioReceipt } from './types';
import * as geminiService from './services/geminiService';
import { decode, decodeAudioData } from './utils/audioUtils';
import type { LiveSession, LiveServerMessage } from '@google/genai';

const SCENARIO_START: Scene = {
  id: 'scene-1',
  title: 'Communicating Climate Action to Farmers',
  narrative: "You're a climate advisor meeting with a group of dairy farmers to discuss new environmental regulations and potential climate adaptation strategies. They look skeptical. The air is thick with the smell of hay and apprehension. Your opening words will set the tone for this crucial conversation.",
  baseImage: 'https://picsum.photos/seed/farm/1024/768',
  branches: [
    { id: 'branch-1-1', title: 'Focus on Economic Resilience', prompt: 'Frame the adaptation strategies around economic benefits, like cost savings from new technologies and reduced risk from extreme weather, making their farms more profitable and resilient.' },
    { id: 'branch-1-2', title: 'Appeal to Environmental Stewardship', prompt: 'Focus on their role as stewards of the land, discussing benefits to soil health, water quality, and preserving the farm for future generations.' },
    { id: 'branch-1-3', title: 'Highlight Peer Success Stories', prompt: 'Talk about other farmers in the region who have successfully implemented similar practices, using their stories as proof of concept and leveraging peer influence.' },
  ],
};

const SCENE_2_1_BRANCHES: Branch[] = [
    { id: 'branch-2-1-1', title: 'Present Data-driven Projections', prompt: 'Show them financial models and data from pilot programs that clearly project increased profits and reduced operational costs over 5 years.' },
    { id: 'branch-2-1-2', title: 'Facilitate a Workshop', prompt: 'Run an interactive workshop session where farmers can map out how these new strategies would apply to their own specific farms, addressing their unique concerns directly.' },
    { id: 'branch-2-1-3', title: 'Introduce a Subsidies Expert', prompt: 'Bring in an expert on government grants and subsidies who can explain exactly how they can finance these changes with minimal upfront cost.' },
];

interface PregeneratedScene {
  narrative: string;
  imageSrc: string;
  narrationBuffer: AudioBuffer;
  branches: Branch[];
}

// --- Helper Functions ---
const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result.split(',')[1]);
      } else {
        reject('Failed to convert blob to base64');
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

const fetchImageAsBase64 = async (url: string) => {
    const response = await fetch(url);
    const blob = await response.blob();
    return { base64: await blobToBase64(blob), mimeType: blob.type };
};

const formatTime = (seconds: number) => {
  if (isNaN(seconds) || !isFinite(seconds)) return '00:00';
  const floorSeconds = Math.floor(seconds);
  const min = Math.floor(floorSeconds / 60);
  const sec = floorSeconds % 60;
  return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
};

// --- UI Components ---

const LoadingOverlay: React.FC<{ messages: string[] }> = ({ messages }) => (
  <div className="absolute inset-0 bg-black bg-opacity-70 flex flex-col items-center justify-center z-50 backdrop-blur-sm">
    <div className="w-16 h-16 border-4 border-blue-400 border-t-transparent border-solid rounded-full animate-spin"></div>
    <div className="mt-4 text-center">
      {messages.map((msg, i) => (
        <p key={i} className="text-lg text-gray-200">{msg}</p>
      ))}
    </div>
  </div>
);

const SceneDisplay: React.FC<{ image: string; narrative: string; title: string }> = ({ image, narrative, title }) => (
  <div className="w-full lg:w-3/5 xl:w-2/3 h-full flex flex-col bg-gray-800 rounded-2xl overflow-hidden shadow-2xl scene-transition">
    <img src={image} alt={title} className="w-full h-1/2 object-cover rounded-lg shadow-xl" />
    <div className="p-6 md:p-8 flex-grow overflow-y-auto">
      <h2 className="text-2xl md:text-3xl font-bold text-blue-300 mb-4">{title}</h2>
      <p className="text-base md:text-lg text-gray-300 leading-relaxed">{narrative}</p>
    </div>
  </div>
);

const ConversationControl: React.FC<{ isConversing: boolean; onToggle: () => void; transcription: { user: string, model: string } }> = ({ isConversing, onToggle, transcription }) => (
  <div className="p-6 bg-gray-800 rounded-2xl flex flex-col">
    <h3 className="text-xl font-semibold mb-4 text-blue-300">Live Conversation</h3>
    <div className="flex-grow bg-gray-900 rounded-lg p-4 overflow-y-auto mb-4 h-32">
      <p className="text-gray-400"><strong className="text-cyan-400">You:</strong> {transcription.user}</p>
      <p className="text-gray-400"><strong className="text-purple-400">Guide:</strong> {transcription.model}</p>
    </div>
    <button onClick={onToggle} className={`w-full py-3 px-4 rounded-lg font-bold text-lg transition-all duration-300 flex items-center justify-center ${isConversing ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'}`}>
      {isConversing ? (
        <>
          <svg className="w-6 h-6 mr-2 animate-pulse" fill="currentColor" viewBox="0 0 20 20"><path d="M7 4a3 3 0 016 0v6a3 3 0 11-6 0V4z"/><path fillRule="evenodd" d="M10 18a8 8 0 008-8h-2a6 6 0 11-12 0H2a8 8 0 008 8z" clipRule="evenodd" /></svg>
          Stop Conversation
        </>
      ) : (
        <>
          <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M7 4a3 3 0 016 0v6a3 3 0 11-6 0V4z"/><path fillRule="evenodd" d="M10 18a8 8 0 008-8h-2a6 6 0 11-12 0H2a8 8 0 008 8z" clipRule="evenodd" /></svg>
          Start Conversation
        </>
      )}
    </button>
  </div>
);

const NarrationControls: React.FC<{
  playbackState: { isPlaying: boolean; progress: number; duration: number };
  onPlayPause: () => void;
  onSeek: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onReplay: () => void;
  hasNarration: boolean;
}> = ({ playbackState, onPlayPause, onSeek, onReplay, hasNarration }) => {
  return (
    <div className="p-6 bg-gray-800 rounded-2xl">
      <h3 className="text-xl font-semibold mb-4 text-blue-300">Narration</h3>
      <div className="flex items-center gap-4">
        <button onClick={onReplay} disabled={!hasNarration} className="p-2 rounded-full bg-gray-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 8.188A9 9 0 1015.813 15.812" /></svg>
        </button>
        <button onClick={onPlayPause} disabled={!hasNarration} className="p-3 rounded-full bg-blue-500 hover:bg-blue-600 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors">
          {playbackState.isPlaying ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6" /></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /></svg>
          )}
        </button>
        <div className="flex-grow flex items-center gap-2">
          <span className="text-sm font-mono text-gray-400">{formatTime(playbackState.progress)}</span>
          <input
            type="range"
            min="0"
            max={playbackState.duration}
            value={playbackState.progress}
            onChange={onSeek}
            disabled={!hasNarration}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer disabled:cursor-not-allowed"
          />
          <span className="text-sm font-mono text-gray-400">{formatTime(playbackState.duration)}</span>
        </div>
      </div>
    </div>
  );
};

const ChoiceButtons: React.FC<{ branches: Branch[]; onChoice: (branch: Branch) => void }> = ({ branches, onChoice }) => (
    <div className="p-6 bg-gray-800 rounded-2xl">
        <h3 className="text-xl font-semibold mb-4 text-blue-300">Your Choices</h3>
        <div className="space-y-3">
            {branches.map(branch => (
                <button key={branch.id} onClick={() => onChoice(branch)} className="w-full text-left p-4 bg-gray-700 hover:bg-blue-800 rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 hover:-translate-y-1 active:scale-95">
                    <p className="font-semibold text-lg">{branch.title}</p>
                </button>
            ))}
        </div>
    </div>
);


const ReceiptDisplay: React.FC<{ receipt: BranchingScenarioReceipt | null }> = ({ receipt }) => {
    const [isOpen, setIsOpen] = useState(false);
    if (!receipt) return null;
    return (
        <div className="fixed bottom-0 left-0 right-0 z-10">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full bg-gray-700 text-blue-300 p-2 text-center font-mono">
                {isOpen ? 'Hide' : 'Show'} Constitutional Receipt
            </button>
            {isOpen && (
                <div className="bg-gray-900 bg-opacity-90 p-4 max-h-64 overflow-y-auto">
                    <pre className="text-xs text-green-400 whitespace-pre-wrap">{JSON.stringify(receipt, null, 2)}</pre>
                </div>
            )}
        </div>
    );
};


// --- Main App Component ---

export default function App() {
  const [currentScene, setCurrentScene] = useState<Scene>(SCENARIO_START);
  const [sceneImage, setSceneImage] = useState<string>(SCENARIO_START.baseImage);
  const [imageStyle, setImageStyle] = useState('vibrant, whimsical 3D animated style reminiscent of modern animated feature films');
  const [loadingMessages, setLoadingMessages] = useState<string[]>([]);
  const [receipt, setReceipt] = useState<BranchingScenarioReceipt | null>(null);
  const [isConversing, setIsConversing] = useState(false);
  const [transcription, setTranscription] = useState({ user: '', model: '' });
  
  // Pre-generation cache
  const [pregeneratedScenes, setPregeneratedScenes] = useState<Map<string, PregeneratedScene>>(new Map());

  // Narration State
  const [narrationState, setNarrationState] = useState<{
    buffer: AudioBuffer | null;
    isPlaying: boolean;
    progress: number;
    duration: number;
  }>({ buffer: null, isPlaying: false, progress: 0, duration: 0 });

  const narrationAudioContextRef = useRef<AudioContext | null>(null);
  const narrationSourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const playbackStartCtxTimeRef = useRef(0);
  const playbackPauseOffsetRef = useRef(0);
  const animationFrameIdRef = useRef(0);

  const liveSessionRef = useRef<Promise<LiveSession> | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  const currentInputTranscriptionRef = useRef('');
  const currentOutputTranscriptionRef = useRef('');


  const generateReceipt = useCallback((branch: Branch, wallClockMs: number, parentSceneId: string) => {
    const newReceipt: BranchingScenarioReceipt = {
        id: `receipt-${Date.now()}`,
        timestamp: new Date().toISOString(),
        scenario: {
            type: 'education',
            branch_id: branch.id,
            depth: 1,
            parent_branch: parentSceneId,
        },
        execution: {
            parallel_operations: 3,
            wall_clock_ms: wallClockMs,
            models_used: [
                { model: 'gemini-2.5-pro', role: 'narrative' },
                { model: 'gemini-2.5-flash-image', role: 'visual' },
                { model: 'gemini-2.5-flash-preview-tts', role: 'narration' },
            ],
        },
        constitutional: {
            yama_principles: { satya: { checked: true, passed: true }, asteya: { checked: true, passed: true }, ahimsa: { checked: true, passed: true }, brahmacharya: { checked: true, passed: true }, },
            embedding_placeholder: 'Embedding generation requires a separate service.',
        },
        quality: { narrative_coherence: 0.9, visual_alignment: 0.85, voice_naturalness: 0.95 },
        outcome: { branch_selected: branch.title, questions_asked: 0 },
        signature: 'mock-ed25519-signature-placeholder',
    };
    setReceipt(newReceipt);
  }, []);

  // --- Narration Handlers ---
  const cleanupNarration = useCallback(() => {
    if (narrationSourceNodeRef.current) {
      narrationSourceNodeRef.current.onended = null;
      narrationSourceNodeRef.current.stop();
      narrationSourceNodeRef.current.disconnect();
      narrationSourceNodeRef.current = null;
    }
    cancelAnimationFrame(animationFrameIdRef.current);
  }, []);
  
  const playNarration = useCallback((buffer: AudioBuffer, resumeFrom: number) => {
    cleanupNarration();
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!narrationAudioContextRef.current || narrationAudioContextRef.current.state === 'closed') {
      narrationAudioContextRef.current = new AudioContext({ sampleRate: 24000 });
    }
    narrationAudioContextRef.current.resume();

    const source = narrationAudioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(narrationAudioContextRef.current.destination);
    source.start(0, resumeFrom);
    narrationSourceNodeRef.current = source;

    playbackStartCtxTimeRef.current = narrationAudioContextRef.current.currentTime - resumeFrom;
    setNarrationState(prev => ({ ...prev, isPlaying: true, duration: buffer.duration }));
    
    const updateProgress = () => {
      if (!narrationAudioContextRef.current || !narrationSourceNodeRef.current) return;
      const progress = narrationAudioContextRef.current.currentTime - playbackStartCtxTimeRef.current;
      setNarrationState(prev => ({ ...prev, progress: Math.min(progress, prev.duration) }));
      animationFrameIdRef.current = requestAnimationFrame(updateProgress);
    };
    updateProgress();

    source.onended = () => {
      cleanupNarration();
      setNarrationState(prev => {
        if (prev.isPlaying) {
          playbackPauseOffsetRef.current = 0;
          return { ...prev, isPlaying: false, progress: prev.duration };
        }
        return prev;
      });
    };
  }, [cleanupNarration]);
  
  const pauseNarration = useCallback(() => {
    if (!narrationAudioContextRef.current || !narrationState.isPlaying) return;
    playbackPauseOffsetRef.current = narrationAudioContextRef.current.currentTime - playbackStartCtxTimeRef.current;
    cleanupNarration();
    setNarrationState(prev => ({ ...prev, isPlaying: false }));
  }, [cleanupNarration, narrationState.isPlaying]);

  const handlePlayPause = useCallback(() => {
    if (narrationState.isPlaying) {
      pauseNarration();
    } else if (narrationState.buffer) {
      playNarration(narrationState.buffer, playbackPauseOffsetRef.current);
    }
  }, [narrationState.isPlaying, narrationState.buffer, pauseNarration, playNarration]);

  const handleReplay = useCallback(() => {
    if (narrationState.buffer) {
      playbackPauseOffsetRef.current = 0;
      playNarration(narrationState.buffer, 0);
    }
  }, [narrationState.buffer, playNarration]);

  const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (narrationState.buffer) {
      const newTime = parseFloat(e.target.value);
      playbackPauseOffsetRef.current = newTime;
      setNarrationState(prev => ({...prev, progress: newTime}));
      if(narrationState.isPlaying) {
         playNarration(narrationState.buffer, newTime);
      }
    }
  }, [narrationState.buffer, narrationState.isPlaying, playNarration]);

  // --- Main Logic ---

  // Effect to pre-generate branches for the current scene
  useEffect(() => {
    const pregenerateBranches = async () => {
      console.log(`Starting pre-generation for branches of scene: ${currentScene.title}`);
      const { base64: currentImageB64, mimeType } = await fetchImageAsBase64(sceneImage);

      for (const branch of currentScene.branches) {
        // Fire-and-forget generation for each branch
        (async () => {
          try {
            // Run image and narrative generation in parallel
            const imagePromise = geminiService.editImage(currentImageB64, mimeType, branch.prompt, imageStyle);
            const narrativePromise = geminiService.generateNarrative(branch.prompt);
            
            // Once narrative is done, run narration and branch generation in parallel
            const newNarrative = await narrativePromise;
            const narrationPromise = geminiService.generateNarration(newNarrative);
            const branchesPromise = branch.id === 'branch-1-1'
              ? Promise.resolve(SCENE_2_1_BRANCHES)
              : geminiService.generateBranches(newNarrative);
            
            // Await all promises to resolve
            const [newImageB64, newNarrationB64, nextBranches] = await Promise.all([
              imagePromise,
              narrationPromise,
              branchesPromise,
            ]);

            if (!newNarrationB64) throw new Error("Narration generation failed silently.");

            const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
            const tempAudioCtx = new AudioContext({ sampleRate: 24000 });
            const narrationBuffer = await decodeAudioData(decode(newNarrationB64), tempAudioCtx, 24000, 1);
            await tempAudioCtx.close();

            const sceneData: PregeneratedScene = {
              narrative: newNarrative,
              imageSrc: `data:${mimeType};base64,${newImageB64}`,
              narrationBuffer,
              branches: nextBranches,
            };

            setPregeneratedScenes(prev => new Map(prev).set(branch.id, sceneData));
            console.log(`Successfully pre-generated and cached branch: ${branch.title}`);
          } catch (error) {
            console.error(`Error pre-generating branch "${branch.title}":`, error);
          }
        })();
      }
    };

    if(currentScene.branches.length > 0) {
        pregenerateBranches();
    }
  }, [currentScene.id, currentScene.title, currentScene.branches, sceneImage, imageStyle]);


  const handleChoice = useCallback(async (branch: Branch) => {
    setLoadingMessages([]);
    pauseNarration();

    const parentSceneId = currentScene.id;
    const startTime = Date.now();
    const cachedScene = pregeneratedScenes.get(branch.id);

    if (cachedScene) {
      // --- CACHED PATH: Instant transition ---
      console.log("Loading scene from pre-generated cache.");
      const newScene: Scene = { 
        id: branch.id, 
        title: branch.title, 
        narrative: cachedScene.narrative, 
        baseImage: cachedScene.imageSrc,
        branches: cachedScene.branches,
      };
      
      setCurrentScene(newScene);
      setSceneImage(cachedScene.imageSrc);

      playbackPauseOffsetRef.current = 0;
      const buffer = cachedScene.narrationBuffer;
      setNarrationState({ buffer, isPlaying: false, progress: 0, duration: buffer.duration });
      playNarration(buffer, 0);

      const wallClockMs = Date.now() - startTime;
      generateReceipt(branch, wallClockMs, parentSceneId);

      setPregeneratedScenes(new Map());
    } else {
      // --- FALLBACK PATH: On-demand generation ---
      console.log("Pregenerated scene not found, generating on demand.");
      setLoadingMessages([
        "Generating narrative...",
        "Creating visuals...",
      ]);

      try {
        const { base64: currentImageB64, mimeType } = await fetchImageAsBase64(sceneImage);
        
        // Run image and narrative generation in parallel
        const imagePromise = geminiService.editImage(currentImageB64, mimeType, branch.prompt, imageStyle);
        const narrativePromise = geminiService.generateNarrative(branch.prompt);
        
        // Wait for the narrative first, as it's needed for the next steps
        const newNarrative = await narrativePromise;
        
        // Update messages to reflect the next set of parallel tasks
        setLoadingMessages([
          "Synthesizing narration...",
          "Planning next choices...",
        ]);
        
        const narrationPromise = geminiService.generateNarration(newNarrative);
        const branchesPromise = branch.id === 'branch-1-1'
          ? Promise.resolve(SCENE_2_1_BRANCHES)
          : geminiService.generateBranches(newNarrative);
        
        // Await all promises to resolve
        const [newImageB64, newNarrationB64, nextBranches] = await Promise.all([
          imagePromise,
          narrationPromise,
          branchesPromise,
        ]);
        
        const wallClockMs = Date.now() - startTime;
        generateReceipt(branch, wallClockMs, parentSceneId);

        const newScene: Scene = { 
            id: branch.id, 
            title: branch.title, 
            narrative: newNarrative,
            baseImage: `data:${mimeType};base64,${newImageB64}`,
            branches: nextBranches 
        };
        setCurrentScene(newScene);
        setSceneImage(`data:${mimeType};base64,${newImageB64}`);
        
        setPregeneratedScenes(new Map());

        if (newNarrationB64) {
          const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
          const tempAudioCtx = new AudioContext({ sampleRate: 24000 });
          const audioBuffer = await decodeAudioData(decode(newNarrationB64), tempAudioCtx, 24000, 1);
          await tempAudioCtx.close();
          
          playbackPauseOffsetRef.current = 0;
          setNarrationState({ buffer: audioBuffer, isPlaying: false, progress: 0, duration: audioBuffer.duration });
          playNarration(audioBuffer, 0);
        } else {
          setNarrationState({ buffer: null, isPlaying: false, progress: 0, duration: 0 });
        }
      } catch (error) {
        console.error("On-demand generation failed:", error);
      } finally {
        setLoadingMessages([]);
      }
    }
  }, [currentScene.id, sceneImage, imageStyle, generateReceipt, playNarration, pauseNarration, pregeneratedScenes]);

  // --- Live API Handlers ---
  const stopConversation = useCallback(async () => {
    if (liveSessionRef.current) {
        const session = await liveSessionRef.current;
        session.close();
        liveSessionRef.current = null;
    }
    if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
    }
    if (scriptProcessorRef.current) {
        scriptProcessorRef.current.disconnect();
        scriptProcessorRef.current = null;
    }
    if(inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
      inputAudioContextRef.current.close();
    }
    audioSourcesRef.current.forEach(source => source.stop());
    audioSourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    
    setIsConversing(false);
  }, []);

  const startConversation = useCallback(async () => {
    if (isConversing) {
        await stopConversation();
        return;
    }

    setIsConversing(true);
    setTranscription({ user: '', model: '' });
    currentInputTranscriptionRef.current = '';
    currentOutputTranscriptionRef.current = '';

    try {
        mediaStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        inputAudioContextRef.current = new AudioContext({ sampleRate: 16000 });
        outputAudioContextRef.current = new AudioContext({ sampleRate: 24000 });
        
        const callbacks = {
          onOpen: () => {
              console.log('Live session opened.');
              if (!mediaStreamRef.current || !inputAudioContextRef.current) return;
              
              const source = inputAudioContextRef.current.createMediaStreamSource(mediaStreamRef.current);
              scriptProcessorRef.current = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
              
              scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
                  const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                  const pcmBlob = geminiService.createAudioBlob(inputData);
                  liveSessionRef.current?.then((session) => session.sendRealtimeInput({ media: pcmBlob }));
              };

              source.connect(scriptProcessorRef.current);
              scriptProcessorRef.current.connect(inputAudioContextRef.current.destination);
          },
          onMessage: async (message: LiveServerMessage) => {
              if (message.serverContent?.inputTranscription) {
                  currentInputTranscriptionRef.current += message.serverContent.inputTranscription.text;
                  setTranscription(prev => ({ ...prev, user: currentInputTranscriptionRef.current }));
              }
              if (message.serverContent?.outputTranscription) {
                  currentOutputTranscriptionRef.current += message.serverContent.outputTranscription.text;
                  setTranscription(prev => ({ ...prev, model: currentOutputTranscriptionRef.current }));
              }
              if (message.serverContent?.turnComplete) {
                  currentInputTranscriptionRef.current = '';
                  currentOutputTranscriptionRef.current = '';
              }
              
              const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (audioData && outputAudioContextRef.current) {
                  const audioBuffer = await decodeAudioData(decode(audioData), outputAudioContextRef.current, 24000, 1);
                  const source = outputAudioContextRef.current.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(outputAudioContextRef.current.destination);
                  
                  const currentTime = outputAudioContextRef.current.currentTime;
                  const startTime = Math.max(currentTime, nextStartTimeRef.current);
                  source.start(startTime);
                  nextStartTimeRef.current = startTime + audioBuffer.duration;
                  
                  audioSourcesRef.current.add(source);
                  source.onended = () => audioSourcesRef.current.delete(source);
              }
          },
          onError: (e: Event) => {
              console.error('Live session error:', e);
              stopConversation();
          },
          onClose: (e: CloseEvent) => {
              console.log('Live session closed.');
              stopConversation();
          },
        };

        liveSessionRef.current = geminiService.connectLive(callbacks, currentScene.narrative);
    } catch (error) {
        console.error("Failed to start conversation:", error);
        setIsConversing(false);
    }
  }, [isConversing, stopConversation, currentScene.narrative]);

  useEffect(() => {
    return () => {
        stopConversation();
        cleanupNarration();
        if (narrationAudioContextRef.current && narrationAudioContextRef.current.state !== 'closed') {
          narrationAudioContextRef.current.close();
        }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main className="relative min-h-screen bg-gray-900 text-white p-4 md:p-6 lg:p-8 font-sans">
      <div className="max-w-7xl mx-auto h-full">
        <header className="text-center mb-6">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
            Gemini<span className="text-blue-400">: Branching Scenario</span>
          </h1>
          <p className="mt-2 text-lg text-gray-400">An AI-driven interactive narrative experience.</p>
        </header>

        <div className="relative flex flex-col lg:flex-row gap-6 lg:gap-8" style={{height: 'calc(100vh - 150px)'}}>
          {loadingMessages.length > 0 && <LoadingOverlay messages={loadingMessages} />}
          
          <SceneDisplay key={currentScene.id} image={sceneImage} narrative={currentScene.narrative} title={currentScene.title} />

          <div className="w-full lg:w-2/5 xl:w-1/3 h-full flex flex-col gap-6 lg:gap-8">
            <ConversationControl isConversing={isConversing} onToggle={startConversation} transcription={transcription} />
            <NarrationControls
                playbackState={narrationState}
                onPlayPause={handlePlayPause}
                onSeek={handleSeek}
                onReplay={handleReplay}
                hasNarration={!!narrationState.buffer}
            />
            <ChoiceButtons branches={currentScene.branches} onChoice={handleChoice} />
          </div>
        </div>
      </div>
      <ReceiptDisplay receipt={receipt} />
    </main>
  );
}