import { GoogleGenAI, Modality, LiveServerMessage, Blob as GenAIBlob, Type } from "@google/genai";
import { encode } from '../utils/audioUtils';
import type { Branch } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateNarrative = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: `Generate a short, engaging narrative continuation for a branching scenario. The user's choice led to this. Keep it to one or two paragraphs. Prompt: "${prompt}"`,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating narrative:", error);
    return "The story takes an unexpected turn, but the path is shrouded in digital mist. Please try again.";
  }
};

export const editImage = async (base64Image: string, mimeType: string, prompt: string, style: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: base64Image, mimeType } },
          { text: `Edit this image to reflect the following scene: ${prompt}. Render it in a ${style} style.` },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }
    throw new Error("No image generated");
  } catch (error) {
    console.error("Error editing image:", error);
    return base64Image; // Return original image on error
  }
};

export const generateNarration = async (text: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
        return base64Audio;
    }
    throw new Error("No audio generated");
  } catch (error) {
    console.error("Error generating narration:", error);
    return "";
  }
};

export const generateBranches = async (narrative: string): Promise<Branch[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Based on this narrative, create 3 distinct choices for the user to continue the story. Each choice should have a unique ID like 'branch-X-Y-Z'. Narrative: "${narrative}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING, description: "A unique identifier for the branch, e.g., branch-2-1-1" },
              title: { type: Type.STRING, description: "A short, compelling title for the choice." },
              prompt: { type: Type.STRING, description: "A detailed prompt for the AI to generate the next scene's narrative and image." }
            },
            required: ["id", "title", "prompt"],
          },
        },
      },
    });

    const jsonString = response.text.trim();
    const branches = JSON.parse(jsonString);
    if (Array.isArray(branches) && branches.length > 0 && branches.every(b => b.id && b.title && b.prompt)) {
        return branches;
    }
    throw new Error("Generated branches are not in the expected format.");

  } catch (error) {
    console.error("Error generating branches:", error);
    return [{
      id: 'fallback-1',
      title: "Continue the story",
      prompt: "The story continues, following the consequences of your last action."
    }];
  }
};

interface LiveCallbacks {
    onOpen: () => void;
    onMessage: (message: LiveServerMessage) => void;
    onError: (event: Event) => void;
    onClose: (event: CloseEvent) => void;
}

export const connectLive = (callbacks: LiveCallbacks, sceneDescription: string) => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
            onopen: callbacks.onOpen,
            onmessage: callbacks.onMessage,
            onerror: callbacks.onError,
            onclose: callbacks.onClose,
        },
        config: {
            responseModalities: [Modality.AUDIO],
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            systemInstruction: `You are a guide in an interactive scenario. The current situation is: "${sceneDescription}". Engage naturally. Answer questions about the scenario world. Be conversational, not robotic.`,
        },
    });
};


export function createAudioBlob(data: Float32Array): GenAIBlob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}