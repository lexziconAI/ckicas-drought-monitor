# CAIS Academic Paper Formatter - User Guide

## Overview

The CAIS formatter skill enables you to convert JSON, Markdown, or plain text files into properly formatted academic papers following the Communications of the Association for Information Systems (CAIS) style guidelines.

## Installation

1. Download the `cais-formatter.skill` file
2. In Claude.ai, go to Settings → Skills
3. Click "Add Skill" and upload the `.skill` file
4. The skill will now be available for use

## What This Skill Does

The CAIS formatter automatically:

✅ **Converts passive voice to active voice** (e.g., "was analyzed" → "we analyzed")  
✅ **Ensures correct tense usage** (present for discussing papers, past for methodology)  
✅ **Fixes word choices** (replaces "utilize" with "use", removes "very", etc.)  
✅ **Formats citations properly** (APA style without DOIs)  
✅ **Corrects quote punctuation** (CAIS-specific rules)  
✅ **Validates style compliance** (checks for vague language, nominalizations, etc.)  
✅ **Generates formatted documents** (Markdown or Word format)

## Quick Start

### Option 1: Upload an Existing File

Simply upload your JSON, Markdown, or text file and say:

```
Convert this to CAIS format
```

Claude will process your file and provide a formatted version.

### Option 2: Use the JSON Template

1. Download the example template from the skill:
   ```
   Show me the example JSON paper template
   ```

2. Create your paper content in JSON format (see structure below)

3. Upload your JSON file and request formatting:
   ```
   Format this paper according to CAIS guidelines
   ```

### Option 3: Convert Existing Text

Paste your paper text or upload a Markdown/text file:

```
I have a draft paper I need to format for CAIS submission. 
Can you convert it to the proper format?
```

## Input Formats

### JSON Structure

The most structured option provides the best results:

```json
{
  "title": "Your Paper Title",
  "authors": [
    {
      "name": "First Author",
      "affiliation": "University",
      "email": "email@example.com"
    }
  ],
  "abstract": "Your abstract text...",
  "keywords": ["keyword1", "keyword2", "keyword3"],
  "sections": [
    {
      "heading": "Introduction",
      "level": 1,
      "content": "Your introduction text..."
    },
    {
      "heading": "Literature Review",
      "level": 1,
      "content": "Your literature review..."
    }
  ],
  "references": [
    {
      "type": "journal",
      "authors": ["Author, A.", "Author, B."],
      "year": 2020,
      "title": "Article title",
      "journal": "Journal Name",
      "volume": "15",
      "issue": "3",
      "pages": "100-120"
    }
  ]
}
```

### Markdown Format

```markdown
# Your Paper Title

**Authors:** First Author, Second Author

## Abstract
Your abstract here...

## Introduction
Your introduction text...

## References
Author, A. (2020). Paper title...
```

### Plain Text

```
Your Paper Title

Authors: First Author, Second Author

Abstract
Your abstract here...

Introduction
Your introduction text...
```

## Example Usage Scenarios

### Scenario 1: Quick Draft Conversion

**You:**
> I have this rough draft I need to format for CAIS. Here's the content:
> [paste your text]

**Claude will:**
- Parse your content into sections
- Apply CAIS style rules
- Fix passive voice, tense, and word choice
- Format citations properly
- Provide a formatted document

### Scenario 2: JSON-Based Paper Creation

**You:**
> I have all my paper content structured in JSON. Can you convert it to CAIS format and generate a Word document?

**Claude will:**
- Load your JSON structure
- Apply all formatting rules
- Generate a downloadable document
- Provide a style validation report

### Scenario 3: Batch Processing

**You:**
> I have 5 papers that need CAIS formatting. Can you process them all?

**Claude will:**
- Use the batch processing script
- Format all papers consistently
- Generate style reports for each
- Provide download links for all outputs

## Style Rules Applied

The skill automatically applies these CAIS-specific rules:

### Voice and Tense
- ✅ Active voice with "I", "we" (not passive constructions)
- ✅ Present tense for discussing papers and models
- ✅ Past tense for methodology
- ✅ Present perfect for contributions

### Word Choice
- ✅ "use" instead of "utilize"
- ✅ "percent" instead of "per cent"
- ✅ "because" instead of "as" (for causation)
- ✅ Removes meaningless "very"
- ✅ Replaces vague phrases with specific references

### Citations
- ✅ APA format: (Author, Year) or Author (Year)
- ✅ Page numbers required for quotes: (Author, Year, p. 15)
- ✅ Use "&" in citations: (Smith & Jones, 2020)
- ✅ Use "and" in text: Smith and Jones (2020) found...
- ✅ No DOIs in reference list

### Formatting
- ✅ Double quotes with punctuation outside: "text here".
- ✅ Serial/Oxford comma: a, b, and c
- ✅ Em dashes for auxiliary information: text—like this—text
- ✅ Numbers under 10 spelled out (except data results)
- ✅ Capitalize Section, Table, Figure when specific

## Advanced Features

### Style Validation

Request a detailed style report:

```
Format my paper and generate a style validation report
```

This produces an HTML report showing:
- Passive voice occurrences
- Vague language
- Citation format issues
- Word choice problems
- Severity levels (error/warning/info)

### Batch Processing

For multiple papers:

```
I have a folder of papers. Can you process them all and generate 
style reports for each?
```

### Custom Formatting

If you need specific sections or formatting:

```
Format this paper but keep the methodology section in past tense 
and add a "Contributions to Practice" section
```

## Common Style Issues Fixed

### Before → After Examples

**Passive voice:**
- ❌ The data was analyzed using SPSS
- ✅ We analyzed the data using SPSS

**Vague language:**
- ❌ Next, we discuss the findings
- ✅ In Section 4, we discuss the findings

**Word choice:**
- ❌ We utilize the technology acceptance model
- ✅ We use the technology acceptance model

**Citations:**
- ❌ Smith and Jones (2020) found that "text here"
- ✅ Smith and Jones (2020) found that "text here" (p. 15)

**Quote punctuation:**
- ❌ "text here." (Smith, 2020)
- ✅ "text here". (Smith, 2020)

## Tips for Best Results

1. **Provide structured input** - JSON format gives the best results
2. **Include all citations** - Ensure every in-text citation has a reference
3. **Define acronyms** - Spell out on first use: information systems (IS)
4. **Review output** - While automated, human review ensures context-appropriate changes
5. **Check references** - Verify reference formatting matches your sources

## Troubleshooting

### "I can't find CAIS guidelines for this"

Make sure you've explicitly mentioned CAIS formatting:
```
Format this according to CAIS style guidelines
```

### "My JSON file has errors"

Validate your JSON structure:
- Check for missing commas
- Ensure all quotes are closed
- Verify bracket matching
- Use a JSON validator online

### "Citations aren't formatting correctly"

Ensure your reference list includes:
- All authors
- Publication year
- Complete title
- Journal/conference name
- Volume, issue, pages (for journals)

### "The style report shows many warnings"

This is normal for first drafts. Common issues:
- Passive voice (easily fixable)
- Vague language (requires context to fix)
- Missing page numbers in quotes (add them)

## Reference Documentation

The skill includes comprehensive reference guides:

- **style-rules.md** - Complete voice, tense, and word choice rules
- **formatting-guide.md** - Punctuation, numbers, and structural formatting
- **citation-examples.md** - APA/CAIS citation formats and examples

Ask to see any of these for detailed guidance:
```
Show me the CAIS citation formatting rules
```

## Support and Questions

If you encounter issues or have questions about CAIS formatting:

1. **Ask Claude directly:**
   ```
   I'm not sure if this is correct CAIS format: [paste text]
   ```

2. **Request examples:**
   ```
   Can you show me examples of proper CAIS citation format?
   ```

3. **Get clarification:**
   ```
   The style guide says X but I'm confused about Y
   ```

Claude has access to the complete CAIS style guide and can answer specific formatting questions.

## What's Included

Your CAIS formatter skill includes:

📄 **SKILL.md** - Main skill instructions and workflow  
📚 **Reference Files:**
   - style-rules.md (voice, tense, word choice)
   - formatting-guide.md (punctuation, structure)
   - citation-examples.md (APA/CAIS citations)

🛠️ **Scripts:**
   - generate_paper.py (main formatting script)
   - batch_format.py (process multiple papers)

📦 **Assets:**
   - CAIS_author_template.doc (official Word template)
   - example_paper.json (JSON structure template)

## Version Information

- **Skill Version:** 1.0
- **CAIS Style Guide Version:** January 2019
- **Supported Formats:** JSON, Markdown, Plain Text
- **Output Formats:** Markdown, HTML style reports

---

## Quick Command Reference

| Task | Command |
|------|---------|
| Format a file | "Convert this to CAIS format" |
| Get JSON template | "Show me the JSON template" |
| Style validation | "Format and validate this paper" |
| Generate report | "Create a style validation report" |
| Batch process | "Format all these papers" |
| Check citation | "Is this citation correct for CAIS?" |
| View style rules | "Show me the CAIS style rules" |

---

**Ready to start?** Upload your paper or ask Claude to show you the example template!
