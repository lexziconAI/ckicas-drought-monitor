#!/usr/bin/env python3
"""
CAIS Checker Pattern Test Script
Creates a minimal document to test the checker pattern implementation.
"""

from docx import Document
from docx.shared import Inches, Pt
from create_academic_docx import add_cais_checker_pattern

def create_checker_test():
    """Create a simple test document with CAIS checker pattern."""

    # Create new document
    doc = Document()

    # Add some test content
    doc.add_heading('CAIS Checker Pattern Test', 0)

    doc.add_heading('Visual Verification', 1)
    doc.add_paragraph('This document tests the CAIS checker pattern implementation.')
    doc.add_paragraph('Look for the vertical alternating green (#2D5F3F) and yellow (#F4C430) rectangles on the right margin.')

    doc.add_heading('Technical Specifications', 1)
    doc.add_paragraph('• Colors: Green #2D5F3F, Yellow #F4C430')
    doc.add_paragraph('• Dimensions: 0.25" width × 0.4" height per checker')
    doc.add_paragraph('• Implementation: Borderless table with cell shading')
    doc.add_paragraph('• Position: Right margin, non-interfering with text')

    # Add multiple paragraphs to test multi-page behavior
    doc.add_heading('Multi-Page Test', 1)
    for i in range(20):
        doc.add_paragraph(f'This is paragraph {i+1} to test how the checker pattern behaves across multiple pages. The pattern should remain visible on the right margin throughout the document.')

    # Add the CAIS checker pattern
    print("Adding CAIS checker pattern...")
    add_cais_checker_pattern(doc, num_checkers=25)

    # Save the test document
    output_path = 'cais_checker_visual_test.docx'
    doc.save(output_path)

    print(f"✅ Test document created: {output_path}")
    print("📋 Open in Microsoft Word to verify the checker pattern appears correctly")

    return output_path

if __name__ == '__main__':
    create_checker_test()