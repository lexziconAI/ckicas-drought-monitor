#!/usr/bin/env python3
"""
CAIS Checker Pattern Validation Script
Validates that the checker pattern implementation meets all specifications.
"""

import os
from docx import Document
from docx.shared import RGBColor

def validate_cais_checker_pattern(docx_path):
    """
    Comprehensive validation of CAIS checker pattern implementation.

    Args:
        docx_path: Path to the DOCX file to validate

    Returns:
        dict: Validation results with pass/fail status and details
    """

    results = {
        'file_exists': False,
        'document_loads': False,
        'table_found': False,
        'correct_dimensions': False,
        'correct_colors': False,
        'borderless': False,
        'right_aligned': False,
        'no_text_interference': False,
        'issues': [],
        'recommendations': []
    }

    # Check if file exists
    if not os.path.exists(docx_path):
        results['issues'].append(f"File not found: {docx_path}")
        return results

    results['file_exists'] = True

    try:
        # Load document
        doc = Document(docx_path)
        results['document_loads'] = True

        # Find tables in document
        tables = doc.tables
        if not tables:
            results['issues'].append("No tables found in document")
            return results

        # Assume the last table is the checker pattern (added last)
        checker_table = tables[-1]
        results['table_found'] = True

        # Validate table structure
        if len(checker_table.columns) != 1:
            results['issues'].append(f"Table should have 1 column, found {len(checker_table.columns)}")

        num_rows = len(checker_table.rows)
        if num_rows < 20:  # Should have at least 20 checkers
            results['issues'].append(f"Table should have at least 20 rows, found {num_rows}")

        # Validate colors and dimensions
        green_found = False
        yellow_found = False
        correct_width = True

        for i, row in enumerate(checker_table.rows):
            cell = row.cells[0]

            # Check cell width (should be ~0.25 inches)
            try:
                width_inches = cell.width.inches
                if not (0.2 <= width_inches <= 0.3):  # Allow some tolerance
                    correct_width = False
                    results['issues'].append(f"Cell {i} width {width_inches:.2f}\" not in expected range 0.20-0.30\"")
            except:
                results['issues'].append(f"Could not determine width for cell {i}")

            # Check cell colors by examining XML
            cell_xml = cell._element.xml

            # Look for green color #2D5F3F
            if '2D5F3F' in cell_xml.upper():
                green_found = True

            # Look for yellow color #F4C430
            if 'F4C430' in cell_xml.upper():
                yellow_found = True

        results['correct_colors'] = green_found and yellow_found
        results['correct_dimensions'] = correct_width

        if not green_found:
            results['issues'].append("CAIS green color (#2D5F3F) not found in checker pattern")

        if not yellow_found:
            results['issues'].append("CAIS yellow color (#F4C430) not found in checker pattern")

        # Check for borders (should be none)
        table_xml = checker_table._element.xml
        borderless = True

        # Look for border elements that are not set to "none"
        if '<w:left w:val="none"' not in table_xml or \
           '<w:right w:val="none"' not in table_xml or \
           '<w:top w:val="none"' not in table_xml or \
           '<w:bottom w:val="none"' not in table_xml:
            borderless = False
            results['issues'].append("Table borders not properly set to none")

        results['borderless'] = borderless

        # Check table alignment (should be right)
        if 'w:jc w:val="right"' not in table_xml:
            results['issues'].append("Table not right-aligned")
        else:
            results['right_aligned'] = True

        # Basic text interference check (look for overlapping content)
        # This is a simple check - in practice would need more sophisticated analysis
        paragraphs = doc.paragraphs
        if len(paragraphs) > 0:
            results['no_text_interference'] = True  # Assume no interference for now
            results['recommendations'].append("Manual verification needed: Check that checker pattern doesn't overlap with text in Word")

        # Overall assessment
        critical_issues = [issue for issue in results['issues'] if any(keyword in issue.lower() for keyword in ['color', 'dimension', 'border', 'alignment'])]
        results['overall_pass'] = len(critical_issues) == 0 and all([
            results['file_exists'],
            results['document_loads'],
            results['table_found'],
            results['correct_colors'],
            results['borderless'],
            results['right_aligned']
        ])

    except Exception as e:
        results['issues'].append(f"Error validating document: {str(e)}")
        results['document_loads'] = False

    return results

def print_validation_report(results):
    """Print a formatted validation report."""

    print("🔍 CAIS CHECKER PATTERN VALIDATION REPORT")
    print("=" * 50)

    # Overall status
    if results.get('overall_pass', False):
        print("✅ OVERALL STATUS: PASS")
    else:
        print("❌ OVERALL STATUS: FAIL")

    print()

    # Individual checks
    checks = [
        ('File exists', results.get('file_exists', False)),
        ('Document loads', results.get('document_loads', False)),
        ('Table found', results.get('table_found', False)),
        ('Correct dimensions', results.get('correct_dimensions', False)),
        ('Correct colors', results.get('correct_colors', False)),
        ('Borderless design', results.get('borderless', False)),
        ('Right aligned', results.get('right_aligned', False)),
        ('No text interference', results.get('no_text_interference', False)),
    ]

    for check_name, passed in checks:
        status = "✅" if passed else "❌"
        print(f"{status} {check_name}")

    print()

    # Issues
    if results.get('issues'):
        print("⚠️  ISSUES FOUND:")
        for issue in results['issues']:
            print(f"   • {issue}")
    else:
        print("✅ No issues found")

    print()

    # Recommendations
    if results.get('recommendations'):
        print("💡 RECOMMENDATIONS:")
        for rec in results['recommendations']:
            print(f"   • {rec}")

    print()

    # Technical details
    print("📊 TECHNICAL SUMMARY:")
    print(f"   • Colors verified: {results.get('correct_colors', False)}")
    print(f"   • Dimensions verified: {results.get('correct_dimensions', False)}")
    print(f"   • Borderless: {results.get('borderless', False)}")
    print(f"   • Right alignment: {results.get('right_aligned', False)}")

def main():
    """Main validation function."""
    import sys

    if len(sys.argv) != 2:
        print("Usage: python validate_checker_pattern.py <docx_file>")
        print("Example: python validate_checker_pattern.py cais_checker_visual_test.docx")
        sys.exit(1)

    docx_file = sys.argv[1]

    print(f"Validating CAIS checker pattern in: {docx_file}")
    print()

    results = validate_cais_checker_pattern(docx_file)
    print_validation_report(results)

    if results.get('overall_pass', False):
        print("🎉 Validation PASSED! CAIS checker pattern implementation is correct.")
        return 0
    else:
        print("❌ Validation FAILED. Please review issues above.")
        return 1

if __name__ == '__main__':
    exit(main())