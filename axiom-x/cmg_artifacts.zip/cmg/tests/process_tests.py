"""
Governance process and workflow tests.
"""
import pytest
import time
import tempfile

from cmg.src.policy_engine import PolicyEngine, ChangeType, RiskClass
from cmg.src.social_oracles import SocialOracles, StakeholderVote, VoteWeight
from cmg.src.meta_scheduler import MetaScheduler, ProposalState, DeliberationConfig
from cmg.src.audit_bridge import AuditBridge, SEADAttestation
from cmg.src.simlab import SimulationLab, SimulationConfig, SimulationScenario

def test_full_governance_lifecycle_low_risk():
    """
    Process: Complete governance lifecycle for LOW-risk proposal.
    
    Workflow: Submit → Deliberation → Voting → Approval → Implementation
    """
    engine = PolicyEngine()
    oracles = SocialOracles()
    
    config = DeliberationConfig(
        min_duration_seconds=0.1,  # Fast for testing
        max_duration_seconds=1.0,
        quorum_threshold=3,
        approval_threshold=0.66
    )
    scheduler = MetaScheduler(oracles, config)
    
    # 1. Submit proposal
    proposal = engine.propose_policy(
        author="test_author",
        rationale="Performance optimization",
        affected_modules=["router"],
        change_type=ChangeType.THRESHOLD_ADJUSTMENT,
        constraints={'aggregate_only': True},
        expected_benefits={'latency_reduction_ms': 10.0},
        risks=["Minimal"],
        test_plan={'scenarios': ['baseline']},
        references=[]
    )
    proposal.risk_class = RiskClass.LOW  # Override for test
    
    workflow = scheduler.submit_proposal(proposal)
    assert workflow.state == ProposalState.DELIBERATION
    
    # 2. Deliberation phase
    time.sleep(0.2)  # Wait minimum
    
    # 3. Voting phase
    scheduler.advance_proposals()
    # Should transition to voting after deliberation
    
    # Cast votes
    for i in range(5):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"voter_{i}",
            proposal_id=proposal.id,
            vote="approve",
            intensity=1.0
        ))
    
    # 4. Advance to approval
    time.sleep(0.2)
    scheduler.advance_proposals()
    
    # 5. Check final state
    final_workflow = scheduler.workflows[proposal.id]
    assert final_workflow.state in [ProposalState.APPROVED, ProposalState.VOTING]


def test_veto_blocks_proposal():
    """
    Process: Stakeholder veto blocks proposal regardless of approval votes.
    """
    engine = PolicyEngine()
    oracles = SocialOracles()
    scheduler = MetaScheduler(oracles)
    
    # Submit proposal
    proposal = engine.propose_policy(
        author="test",
        rationale="Test veto",
        affected_modules=["test"],
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={'aggregate_only': True},
        expected_benefits={},
        risks=[],
        test_plan={'scenarios': ['baseline']},
        references=[]
    )
    proposal.risk_class = RiskClass.LOW
    
    workflow = scheduler.submit_proposal(proposal)
    
    # Cast approval votes
    for i in range(10):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"approver_{i}",
            proposal_id=proposal.id,
            vote="approve",
            intensity=1.0
        ))
    
    # Cast single veto
    oracles.cast_vote(StakeholderVote(
        voter_id="privacy_officer",
        proposal_id=proposal.id,
        vote="veto",
        intensity=1.0,
        justification="Privacy concern"
    ))
    
    # Veto should block
    assert oracles.check_veto(proposal.id) == True


def test_quorum_not_met_rejects_proposal():
    """
    Process: Proposals without quorum are rejected.
    """
    engine = PolicyEngine()
    oracles = SocialOracles()
    
    config = DeliberationConfig(
        min_duration_seconds=0.1,
        max_duration_seconds=0.5,
        quorum_threshold=5,  # Need 5 votes
        approval_threshold=0.66
    )
    scheduler = MetaScheduler(oracles, config)
    
    proposal = engine.propose_policy(
        author="test",
        rationale="Test quorum",
        affected_modules=["test"],
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={'aggregate_only': True},
        expected_benefits={},
        risks=[],
        test_plan={'scenarios': ['baseline']},
        references=[]
    )
    proposal.risk_class = RiskClass.LOW
    
    workflow = scheduler.submit_proposal(proposal)
    
    # Cast only 2 votes (below quorum)
    for i in range(2):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"voter_{i}",
            proposal_id=proposal.id,
            vote="approve",
            intensity=1.0
        ))
    
    # Wait for max duration
    time.sleep(0.6)
    scheduler.advance_proposals()
    
    # Should be rejected due to no quorum
    summary = oracles.get_vote_summary(proposal.id)
    assert summary['quorum_met'] == False


def test_high_risk_requires_human_ratification():
    """
    Process: HIGH-risk proposals wait for human ratification.
    """
    engine = PolicyEngine()
    oracles = SocialOracles()
    scheduler = MetaScheduler(oracles)
    
    # Submit HIGH risk proposal
    proposal = engine.propose_policy(
        author="security_team",
        rationale="Critical security update",
        affected_modules=["authentication"],  # HIGH risk module
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={'aggregate_only': True},
        expected_benefits={'security': 1.0},
        risks=["Authentication failures"],
        test_plan={'scenarios': ['baseline', 'adversarial']},
        references=[]
    )
    assert proposal.risk_class == RiskClass.HIGH
    
    workflow = scheduler.submit_proposal(proposal)
    
    # Should require human ratification
    assert workflow.human_ratification_required == True
    
    # Even with votes, should wait for human
    for i in range(10):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"voter_{i}",
            proposal_id=proposal.id,
            vote="approve",
            intensity=1.0
        ))
    
    # Advance workflow
    scheduler.advance_proposals()
    
    # Should NOT be approved yet
    assert workflow.state != ProposalState.APPROVED or workflow.human_ratified
    
    # Human ratifies
    scheduler.human_ratify(proposal.id, approved=True)
    
    # Now should be approved
    assert workflow.state == ProposalState.APPROVED
    assert workflow.human_ratified == True


def test_audit_trail_completeness():
    """
    Process: Complete audit trail exists for governance actions.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        bridge = AuditBridge(f"{tmpdir}/audit.log")
        
        # Simulate complete governance lifecycle
        actions = ["propose", "deliberate", "vote", "approve", "implement"]
        
        for action in actions:
            attestation = SEADAttestation(
                thermodynamic_realism=True,
                pluralism=True,
                privacy_preserving=True,
                non_coercion=True,
                graceful_degradation=True,
                interpretable_feedback=True,
                deep_time_evaluation=True
            )
            
            bridge.create_receipt(
                policy_content={'action': action},
                action=action,
                actor="system",
                justification=f"Governance {action} action",
                risk_class="LOW",
                sead_attestation=attestation
            )
        
        # Verify chain integrity
        assert bridge.verify_chain()
        
        # Verify all actions recorded
        for action in actions:
            receipts = bridge.get_receipts_by_action(action)
            assert len(receipts) >= 1


def test_simulation_before_voting():
    """
    Process: Proposals must pass simulation before advancing to voting.
    """
    config = {'performance': {'base_latency_ms': 100}}
    lab = SimulationLab(config)
    
    policy_changes = {'performance': {'base_latency_ms': 150}}
    
    sim_config = SimulationConfig(
        scenarios=[SimulationScenario.BASELINE, SimulationScenario.PESSIMISTIC],
        duration_seconds=60,
        sample_size=1000,
        chaos_enabled=False
    )
    
    reports = lab.simulate_impact(policy_changes, sim_config)
    
    # Check if simulations pass acceptance criteria
    for report in reports:
        # Latency increase should be acceptable
        if abs(report.latency_delta_ms) > 100:
            # Would block proposal from voting
            assert report.risk_assessment == "HIGH"


def test_rollback_within_window():
    """
    Process: Rollback can be requested within 7-day window.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        from cmg.src.policy_store import PolicyStore
        
        store = PolicyStore(tmpdir)
        
        # Implement policy
        v1 = store.store_policy_version(
            policy_id="test_policy",
            content={'value': 100},
            author="admin",
            change_summary="Initial",
            create_snapshot=True
        )
        
        snapshot_id = v1.rollback_snapshot_id
        
        # New version
        v2 = store.store_policy_version(
            policy_id="test_policy",
            content={'value': 200},
            author="admin",
            change_summary="Update"
        )
        
        # Simulate discovering issue
        # Request rollback (within 7 days)
        if snapshot_id:
            success = store.rollback(snapshot_id)
            assert success
            
            # Should be back to v1
            current = store.current_versions["test_policy"]
            assert current.content['value'] == 100
Should I continue with the runbooks and remaining artifacts?RetryRDyesOrchestrated comprehensive artifact creation across multiple documentation layers.The user wants me to continue with the runbooks and remaining artifacts. I should create:

cmg_ops.md - Operations runbook
cmg_smoke.md - Smoke test runbook
cmg_schema.json - Telemetry schema
cmg_eval_plan.md - Evaluation protocol with APA 7 references
cmg_brief.md - Decision brief with methodological notes
Integration diffs for AXIOM-X v8
L4 SELF-REFLEXIVE and L5 CONSTITUTIONAL ASSEMBLY analysis
Final convergence verification with chaos injections

Let me continue systematically.CMG-1 DESIGN ARTIFACTS — CONTINUED (PART 7)

PART 7: RUNBOOKS
Runbook 1: cmg_ops.md