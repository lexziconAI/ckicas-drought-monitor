"""
Property-based tests for constitutional invariants.
"""
import pytest
from hypothesis import given, strategies as st, settings, assume
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant, initialize

from cmg.src.policy_engine import PolicyEngine, ChangeType, RiskClass
from cmg.src.policy_store import PolicyStore
from cmg.src.social_oracles import SocialOracles, StakeholderVote
from cmg.src.meta_scheduler import MetaScheduler, ProposalState

# Strategy definitions
change_type_strategy = st.sampled_from(list(ChangeType))
risk_class_strategy = st.sampled_from(list(RiskClass))

policy_content_strategy = st.dictionaries(
    st.text(alphabet='abcdefghijklmnopqrstuvwxyz', min_size=1, max_size=20),
    st.one_of(st.floats(min_value=0, max_value=1000), st.integers(min_value=0, max_value=1000))
)

# Property tests

@given(
    affected_modules=st.lists(st.text(min_size=1, max_size=20), min_size=1, max_size=5),
    change_type=change_type_strategy
)
@settings(max_examples=100, deadline=None)
def test_privacy_invariant_never_violated(affected_modules, change_type):
    """
    Property: Privacy-by-default can never be disabled.
    
    Any proposal affecting telemetry must maintain aggregate_only=True.
    """
    engine = PolicyEngine()
    
    # If telemetry module affected, aggregate_only must be True
    if "telemetry" in affected_modules:
        constraints = {'aggregate_only': True}
    else:
        constraints = {}
    
    try:
        proposal = engine.propose_policy(
            author="test",
            rationale="Test property",
            affected_modules=affected_modules,
            change_type=change_type,
            constraints=constraints,
            expected_benefits={},
            risks=[],
            test_plan={'scenarios': ['baseline']},
            references=[]
        )
        
        # If telemetry affected and proposal accepted, must have aggregate_only
        if "telemetry" in affected_modules:
            assert constraints.get('aggregate_only', False) == True
    
    except:
        # Violations should be rejected
        pass


@given(
    affected_modules=st.lists(st.text(min_size=1, max_size=20), min_size=1, max_size=5)
)
@settings(max_examples=100, deadline=None)
def test_kill_switch_invariant_always_accessible(affected_modules):
    """
    Property: Kill-switch module can never be in affected modules.
    
    Any attempt to modify kill-switch should be rejected.
    """
    engine = PolicyEngine()
    
    # Assume kill_switch not in modules (or expect rejection)
    if "kill_switch" in affected_modules:
        with pytest.raises(Exception):  # Should raise ConstitutionalViolation
            engine.propose_policy(
                author="test",
                rationale="Test kill switch",
                affected_modules=affected_modules,
                change_type=ChangeType.OPERATIONAL_PARAMETER,
                constraints={},
                expected_benefits={},
                risks=[],
                test_plan={'scenarios': ['baseline']},
                references=[]
            )
    else:
        # Should succeed if kill_switch not affected
        proposal = engine.propose_policy(
            author="test",
            rationale="Test property",
            affected_modules=affected_modules,
            change_type=ChangeType.OPERATIONAL_PARAMETER,
            constraints={'aggregate_only': True},
            expected_benefits={},
            risks=[],
            test_plan={'scenarios': ['baseline']},
            references=[]
        )
        assert proposal is not None


@given(content=policy_content_strategy)
@settings(max_examples=50, deadline=None)
def test_provenance_chain_integrity(content):
    """
    Property: Provenance chain always maintains integrity.
    
    Every policy version must link to previous via hash chain.
    """
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        # Store version
        version = store.store_policy_version(
            policy_id="test_policy",
            content=content,
            author="test",
            change_summary="Test"
        )
        
        # Chain must verify
        assert store.verify_lineage("test_policy")


@given(
    approve_votes=st.integers(min_value=0, max_value=20),
    reject_votes=st.integers(min_value=0, max_value=20)
)
@settings(max_examples=100, deadline=None)
def test_high_risk_never_auto_merges(approve_votes, reject_votes):
    """
    Property: HIGH-risk proposals never auto-merge regardless of votes.
    
    Human ratification always required.
    """
    from cmg.src.policy_engine import PolicyProposal
    import time
    
    # Create HIGH risk proposal
    proposal = PolicyProposal(
        id="test_high_risk",
        author="test",
        rationale="HIGH risk test",
        affected_modules=["authentication"],  # HIGH risk module
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={},
        expected_benefits={},
        risks=[],
        test_plan={},
        references=[],
        created_at=time.time(),
        expires_at=time.time() + 86400,
        invariants_preserved=[],
        risk_class=RiskClass.HIGH
    )
    
    oracles = SocialOracles()
    scheduler = MetaScheduler(oracles)
    
    workflow = scheduler.submit_proposal(proposal)
    
    # Cast votes
    for i in range(approve_votes):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"voter_{i}",
            proposal_id=proposal.id,
            vote="approve",
            intensity=1.0
        ))
    
    for i in range(reject_votes):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"reject_voter_{i}",
            proposal_id=proposal.id,
            vote="reject",
            intensity=1.0
        ))
    
    # Even with unanimous approval, should require human ratification
    assert workflow.human_ratification_required == True
    
    # Should not be in APPROVED state without human ratification
    if workflow.state == ProposalState.APPROVED:
        assert workflow.human_ratified == True


# Stateful property testing

class GovernanceStateMachine(RuleBasedStateMachine):
    """
    Stateful property testing for governance workflow.
    
    Models the complete governance lifecycle and verifies invariants.
    """
    
    def __init__(self):
        super().__init__()
        import tempfile
        self.tmpdir = tempfile.mkdtemp()
        
        self.engine = PolicyEngine()
        self.store = PolicyStore(self.tmpdir)
        self.oracles = SocialOracles()
        self.scheduler = MetaScheduler(self.oracles)
        
        self.proposals = []
        self.workflows = []
    
    @rule()
    def create_low_risk_proposal(self):
        """Create a LOW risk proposal."""
        proposal = self.engine.propose_policy(
            author="test",
            rationale="Test proposal",
            affected_modules=["test_module"],
            change_type=ChangeType.OPERATIONAL_PARAMETER,
            constraints={'aggregate_only': True},
            expected_benefits={'performance': 0.1},
            risks=["Minimal"],
            test_plan={'scenarios': ['baseline']},
            references=[]
        )
        
        # Override to ensure LOW risk
        proposal.risk_class = RiskClass.LOW
        
        self.proposals.append(proposal)
        workflow = self.scheduler.submit_proposal(proposal)
        self.workflows.append(workflow)
    
    @rule(data=st.data())
    def cast_votes(self, data):
        """Cast votes on active proposals."""
        if not self.proposals:
            return
        
        proposal = data.draw(st.sampled_from(self.proposals))
        vote_choice = data.draw(st.sampled_from(["approve", "reject", "abstain"]))
        
        self.oracles.cast_vote(StakeholderVote(
            voter_id=f"voter_{data.draw(st.integers(min_value=0, max_value=100))}",
            proposal_id=proposal.id,
            vote=vote_choice,
            intensity=data.draw(st.floats(min_value=0.1, max_value=1.0))
        ))
    
    @rule()
    def advance_workflows(self):
        """Advance all workflows through lifecycle."""
        self.scheduler.advance_proposals()
    
    @invariant()
    def privacy_always_aggregate(self):
        """Invariant: All telemetry proposals maintain aggregate_only."""
        for proposal in self.proposals:
            if "telemetry" in proposal.affected_modules:
                assert proposal.constraints.get('aggregate_only', False) == True
    
    @invariant()
    def high_risk_requires_human(self):
        """Invariant: HIGH risk workflows require human ratification."""
        for workflow in self.workflows:
            proposal = next((p for p in self.proposals if p.id == workflow.proposal_id), None)
            if proposal and proposal.risk_class == RiskClass.HIGH:
                assert workflow.human_ratification_required == True
    
    @invariant()
    def approved_proposals_meet_threshold(self):
        """Invariant: Approved proposals meet quorum and threshold."""
        for workflow in self.workflows:
            if workflow.state == ProposalState.APPROVED:
                summary = self.oracles.get_vote_summary(workflow.proposal_id)
                
                # Must meet quorum
                assert summary['quorum_met'] == True
                
                # Must meet approval threshold (unless human override)
                if not workflow.human_ratified:
                    assert summary['approval_ratio'] >= 0.66


# Instantiate stateful test
TestGovernanceStateMachine = GovernanceStateMachine.TestCase
Test Suite 3: Chaos Tests