"""
Unit tests for PolicyStore module.
"""
import pytest
import tempfile
from pathlib import Path
from cmg.src.policy_store import PolicyStore, PolicyVersion

def test_policy_store_initialization():
    """Test policy store initializes correctly."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        assert store.store_dir.exists()

def test_store_policy_version():
    """Test storing a new policy version."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        version = store.store_policy_version(
            policy_id="test_policy",
            content={'threshold': 100},
            author="test_author",
            change_summary="Initial version"
        )
        
        assert version.policy_id == "test_policy"
        assert version.previous_hash == "0" * 64  # Genesis
        assert version.signature != ""

def test_policy_lineage():
    """Test that policy versions form a chain."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        # Create first version
        v1 = store.store_policy_version(
            policy_id="test_policy",
            content={'threshold': 100},
            author="author",
            change_summary="Version 1"
        )
        
        # Create second version
        v2 = store.store_policy_version(
            policy_id="test_policy",
            content={'threshold': 150},
            author="author",
            change_summary="Version 2"
        )
        
        # V2 should link to V1
        assert v2.previous_hash == v1.signature

def test_verify_lineage():
    """Test lineage verification detects tampering."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        # Create versions
        store.store_policy_version(
            policy_id="test_policy",
            content={'threshold': 100},
            author="author",
            change_summary="Version 1"
        )
        
        # Verify lineage is intact
        assert store.verify_lineage("test_policy")

def test_rollback():
    """Test rollback to previous snapshot."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        # Create initial version
        v1 = store.store_policy_version(
            policy_id="policy_a",
            content={'value': 1},
            author="author",
            change_summary="V1",
            create_snapshot=True
        )
        
        snapshot_id = v1.rollback_snapshot_id
        
        # Create second version
        store.store_policy_version(
            policy_id="policy_a",
            content={'value': 2},
            author="author",
            change_summary="V2"
        )
        
        # Current should be V2
        current = store.current_versions["policy_a"]
        assert current.content['value'] == 2
        
        # Rollback to snapshot
        if snapshot_id:
            success = store.rollback(snapshot_id)
            assert success
            
            # Should be back to V1
            current = store.current_versions["policy_a"]
            assert current.content['value'] == 1

def test_get_policy_history():
    """Test retrieving complete policy history."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        # Create multiple versions
        for i in range(3):
            store.store_policy_version(
                policy_id="test_policy",
                content={'version': i},
                author="author",
                change_summary=f"Version {i}"
            )
        
        # Get history
        history = store.get_policy_history("test_policy")
        
        assert len(history) == 3
        assert history[0].content['version'] == 0  # Oldest first
        assert history[-1].content['version'] == 2  # Newest last
Should I continue with the remaining test suites (property tests, chaos tests, etc.) and runbooks?RetryRDyes pleaseOrchestrated comprehensive test suites and operational documentation framework.The user wants me to continue with the remaining test suites and runbooks. I'll create:

Property tests
Chaos tests
Accessibility/privacy tests
Process/governance tests
Runbooks (cmg_ops.md and cmg_smoke.md)
Telemetry schema
Evaluation plan

Let me continue with comprehensive test suites and operational documentation.CMG-1 DESIGN ARTIFACTS — CONTINUED (PART 6)

PART 6: REMAINING TEST SUITES
Test Suite 2: Property Tests