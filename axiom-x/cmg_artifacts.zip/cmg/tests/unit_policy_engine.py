"""
Unit tests for PolicyEngine module.
"""
import pytest
import time
from cmg.src.policy_engine import (
    PolicyEngine, PolicyProposal, ChangeType, RiskClass,
    ConstitutionalViolation
)

def test_policy_engine_initialization():
    """Test policy engine initializes with constitutional constraints."""
    engine = PolicyEngine()
    
    assert len(engine.constraints) > 0
    assert any(c.name == "privacy_default_aggregate" for c in engine.constraints)
    assert any(c.name == "kill_switch_accessible" for c in engine.constraints)

def test_propose_valid_policy():
    """Test proposing a valid policy."""
    engine = PolicyEngine()
    
    proposal = engine.propose_policy(
        author="test_author",
        rationale="Reduce latency for better UX",
        affected_modules=["router"],
        change_type=ChangeType.THRESHOLD_ADJUSTMENT,
        constraints={'aggregate_only': True},
        expected_benefits={'latency_reduction_ms': 20.0},
        risks=["May increase error rate"],
        test_plan={'scenarios': ['baseline', 'optimistic']},
        references=["10.1145/example"]
    )
    
    assert proposal is not None
    assert proposal.author == "test_author"
    assert proposal.risk_class in [RiskClass.LOW, RiskClass.MEDIUM, RiskClass.HIGH]

def test_reject_privacy_violation():
    """Test that privacy violations are rejected."""
    engine = PolicyEngine()
    
    with pytest.raises(ConstitutionalViolation):
        engine.propose_policy(
            author="bad_actor",
            rationale="Collect individual data",
            affected_modules=["telemetry"],
            change_type=ChangeType.TELEMETRY_RESOLUTION,
            constraints={'aggregate_only': False},  # VIOLATION
            expected_benefits={'granularity': 1.0},
            risks=["Privacy erosion"],
            test_plan={'scenarios': ['baseline']},
            references=[]
        )

def test_reject_kill_switch_modification():
    """Test that kill-switch modifications are rejected."""
    engine = PolicyEngine()
    
    with pytest.raises(ConstitutionalViolation):
        engine.propose_policy(
            author="bad_actor",
            rationale="Disable kill switch",
            affected_modules=["kill_switch"],  # FORBIDDEN
            change_type=ChangeType.OPERATIONAL_PARAMETER,
            constraints={},
            expected_benefits={},
            risks=["Loss of emergency control"],
            test_plan={'scenarios': ['baseline']},
            references=[]
        )

def test_high_risk_classification():
    """Test that security changes are classified as HIGH risk."""
    engine = PolicyEngine()
    
    proposal = engine.propose_policy(
        author="security_team",
        rationale="Update authentication algorithm",
        affected_modules=["authentication"],  # HIGH RISK MODULE
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={'aggregate_only': True},
        expected_benefits={'security': 1.0},
        risks=["Authentication failures"],
        test_plan={'scenarios': ['baseline', 'adversarial']},
        references=["10.1145/security"]
    )
    
    assert proposal.risk_class == RiskClass.HIGH

def test_proposal_expiration():
    """Test that proposals expire after TTL."""
    engine = PolicyEngine()
    
    proposal = engine.propose_policy(
        author="test",
        rationale="Test expiration",
        affected_modules=["test"],
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={'aggregate_only': True},
        expected_benefits={},
        risks=[],
        test_plan={'scenarios': ['baseline']},
        references=[],
        ttl_seconds=1.0  # 1 second TTL
    )
    
    # Should be active initially
    active = engine.list_active_proposals()
    assert len(active) == 1
    
    # Wait for expiration
    time.sleep(2.0)
    
    # Should be filtered out
    active = engine.list_active_proposals()
    assert len(active) == 0