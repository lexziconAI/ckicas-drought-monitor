"""
Constitutional Meta-Governor: Policy Store
Versioned policy-of-policies with cryptographic hash lineage.
"""
import hashlib
import hmac
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

from axiom.core.transactional_io import TransactionContext, atomic_write, compute_checksum

@dataclass
class PolicyVersion:
    """Immutable policy version with lineage."""
    version_id: str
    policy_id: str
    content: Dict[str, Any]
    previous_hash: str  # Links to previous version (blockchain-style)
    timestamp: float
    author: str
    change_summary: str
    signature: str  # HMAC signature for integrity
    rollback_snapshot_id: Optional[str] = None

@dataclass
class RollbackSnapshot:
    """Complete system state snapshot for rollback."""
    snapshot_id: str
    timestamp: float
    policy_versions: Dict[str, str]  # policy_id -> version_id
    system_state: Dict[str, Any]
    checksum: str

class PolicyStore:
    """
    Versioned storage for policies with cryptographic lineage.
    
    Implements blockchain-style hash chain for tamper detection.
    Supports atomic updates and rollback to previous states.
    """
    
    def __init__(self, store_dir: str, master_key: bytes = None):
        self.store_dir = Path(store_dir)
        self.store_dir.mkdir(parents=True, exist_ok=True)
        
        # Master key for HMAC signatures
        import secrets
        self.master_key = master_key or secrets.token_bytes(32)
        
        # In-memory cache of current policy versions
        self.current_versions: Dict[str, PolicyVersion] = {}
        
        # Load existing policies
        self._load_current_state()
    
    def _load_current_state(self):
        """Load current policy versions from disk."""
        current_state_file = self.store_dir / 'current_state.json'
        
        if current_state_file.exists():
            data = json.loads(current_state_file.read_text())
            
            for policy_id, version_id in data.get('policy_versions', {}).items():
                version = self._load_version(version_id)
                if version:
                    self.current_versions[policy_id] = version
    
    def _load_version(self, version_id: str) -> Optional[PolicyVersion]:
        """Load specific policy version from disk."""
        version_file = self.store_dir / 'versions' / f'{version_id}.json'
        
        if not version_file.exists():
            return None
        
        data = json.loads(version_file.read_text())
        return PolicyVersion(**data)
    
    def _compute_signature(self, version: PolicyVersion) -> str:
        """Compute HMAC signature for policy version."""
        canonical = json.dumps({
            'version_id': version.version_id,
            'policy_id': version.policy_id,
            'content': version.content,
            'previous_hash': version.previous_hash,
            'timestamp': version.timestamp,
            'author': version.author
        }, sort_keys=True).encode('utf-8')
        
        return hmac.new(self.master_key, canonical, hashlib.sha256).hexdigest()
    
    def store_policy_version(
        self,
        policy_id: str,
        content: Dict[str, Any],
        author: str,
        change_summary: str,
        create_snapshot: bool = True
    ) -> PolicyVersion:
        """
        Store new policy version with lineage tracking.
        
        Args:
            policy_id: Unique policy identifier
            content: Policy content (constraints, parameters, etc.)
            author: Who made this change
            change_summary: Human-readable description
            create_snapshot: Whether to create rollback snapshot
        
        Returns: New PolicyVersion
        """
        # Get previous version for hash chain
        previous_version = self.current_versions.get(policy_id)
        previous_hash = previous_version.signature if previous_version else "0" * 64
        
        # Generate version ID
        version_content = f"{policy_id}:{time.time()}:{author}".encode('utf-8')
        version_id = "VER_" + hashlib.sha256(version_content).hexdigest()[:16]
        
        # Create snapshot if requested
        snapshot_id = None
        if create_snapshot and previous_version:
            snapshot = self._create_snapshot()
            snapshot_id = snapshot.snapshot_id
        
        # Create new version
        version = PolicyVersion(
            version_id=version_id,
            policy_id=policy_id,
            content=content,
            previous_hash=previous_hash,
            timestamp=time.time(),
            author=author,
            change_summary=change_summary,
            signature="",  # Will be computed below
            rollback_snapshot_id=snapshot_id
        )
        
        # Sign version
        version.signature = self._compute_signature(version)
        
        # Store atomically
        with TransactionContext(str(self.store_dir)) as txn:
            # Write version file
            version_dir = self.store_dir / 'versions'
            version_dir.mkdir(exist_ok=True)
            
            txn.write(
                f'versions/{version_id}.json',
                asdict(version)
            )
            
            # Update current state
            current_state = {
                'policy_versions': {
                    pid: ver.version_id 
                    for pid, ver in self.current_versions.items()
                },
                'last_updated': time.time()
            }
            current_state['policy_versions'][policy_id] = version_id
            
            txn.write('current_state.json', current_state)
        
        # Update in-memory cache
        self.current_versions[policy_id] = version
        
        return version
    
    def _create_snapshot(self) -> RollbackSnapshot:
        """Create complete system state snapshot for rollback."""
        snapshot_id = "SNAP_" + hashlib.sha256(
            f"{time.time()}".encode('utf-8')
        ).hexdigest()[:16]
        
        # Capture all current policy versions
        policy_versions = {
            policy_id: version.version_id
            for policy_id, version in self.current_versions.items()
        }
        
        # Capture system state (simplified - in production, would snapshot all modules)
        system_state = {
            'timestamp': time.time(),
            'module_configs': {}  # Would contain actual module states
        }
        
        snapshot = RollbackSnapshot(
            snapshot_id=snapshot_id,
            timestamp=time.time(),
            policy_versions=policy_versions,
            system_state=system_state,
            checksum=""  # Will be computed below
        )
        
        # Compute checksum
        snapshot_content = json.dumps({
            'snapshot_id': snapshot.snapshot_id,
            'policy_versions': snapshot.policy_versions,
            'system_state': snapshot.system_state
        }, sort_keys=True).encode('utf-8')
        
        snapshot.checksum = hashlib.sha256(snapshot_content).hexdigest()
        
        # Store snapshot
        snapshot_file = self.store_dir / 'snapshots' / f'{snapshot_id}.json'
        snapshot_file.parent.mkdir(exist_ok=True)
        atomic_write(str(snapshot_file), json.dumps(asdict(snapshot)))
        
        return snapshot
    
    def rollback(self, snapshot_id: str) -> bool:
        """
        Rollback to previous snapshot.
        
        Returns: True if successful, False otherwise
        """
        # Load snapshot
        snapshot_file = self.store_dir / 'snapshots' / f'{snapshot_id}.json'
        
        if not snapshot_file.exists():
            return False
        
        snapshot_data = json.loads(snapshot_file.read_text())
        snapshot = RollbackSnapshot(**snapshot_data)
        
        # Verify checksum
        snapshot_content = json.dumps({
            'snapshot_id': snapshot.snapshot_id,
            'policy_versions': snapshot.policy_versions,
            'system_state': snapshot.system_state
        }, sort_keys=True).encode('utf-8')
        
        expected_checksum = hashlib.sha256(snapshot_content).hexdigest()
        if snapshot.checksum != expected_checksum:
            return False  # Snapshot corrupted
        
        # Restore policy versions
        with TransactionContext(str(self.store_dir)) as txn:
            current_state = {
                'policy_versions': snapshot.policy_versions,
                'last_updated': time.time(),
                'rollback_from': snapshot_id
            }
            
            txn.write('current_state.json', current_state)
        
        # Reload state
        self._load_current_state()
        
        return True
    
    def verify_lineage(self, policy_id: str) -> bool:
        """
        Verify hash chain integrity for a policy.
        
        Returns: True if chain is intact, False if tampered
        """
        current_version = self.current_versions.get(policy_id)
        if not current_version:
            return True  # No policy = no tampering
        
        # Walk backwards through chain
        version = current_version
        
        while version.previous_hash != "0" * 64:
            # Verify signature
            expected_sig = self._compute_signature(version)
            if version.signature != expected_sig:
                return False
            
            # Load previous version
            # Find version with matching signature
            found = False
            for v_file in (self.store_dir / 'versions').glob('*.json'):
                v_data = json.loads(v_file.read_text())
                if v_data['signature'] == version.previous_hash:
                    version = PolicyVersion(**v_data)
                    found = True
                    break
            
            if not found:
                return False  # Chain broken
        
        return True
    
    def get_policy_history(self, policy_id: str) -> List[PolicyVersion]:
        """Get complete version history for a policy."""
        current_version = self.current_versions.get(policy_id)
        if not current_version:
            return []
        
        history = [current_version]
        version = current_version
        
        while version.previous_hash != "0" * 64:
            # Find previous version
            for v_file in (self.store_dir / 'versions').glob('*.json'):
                v_data = json.loads(v_file.read_text())
                if v_data['signature'] == version.previous_hash:
                    version = PolicyVersion(**v_data)
                    history.append(version)
                    break
        
        return list(reversed(history))  # Oldest first
Module 3: social_oracles.py