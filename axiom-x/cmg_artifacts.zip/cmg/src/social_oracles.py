"""
Constitutional Meta-Governor: Social Oracles
Ingestion of community signals, regulator updates, risk registers.
"""
import json
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum

class SignalType(Enum):
    """Types of governance signals."""
    COMMUNITY_VOTE = "community_vote"
    REGULATOR_UPDATE = "regulator_update"
    RISK_ALERT = "risk_alert"
    STAKEHOLDER_VETO = "stakeholder_veto"
    ETHICAL_CONCERN = "ethical_concern"
    PERFORMANCE_METRIC = "performance_metric"

class VoteWeight(Enum):
    """Voting weight methods."""
    ONE_PERSON_ONE_VOTE = "1p1v"
    QUADRATIC = "quadratic"  # Square root of stake
    STAKE_WEIGHTED = "stake_weighted"

@dataclass
class GovernanceSignal:
    """External governance signal."""
    signal_id: str
    signal_type: SignalType
    source: str  # Who/what generated this signal
    content: Dict[str, Any]
    timestamp: float
    confidence: float  # 0.0 to 1.0
    relevant_policies: List[str]  # Which policies this affects
    priority: int  # 1 (low) to 5 (critical)

@dataclass
class StakeholderVote:
    """Individual stakeholder vote on a proposal."""
    voter_id: str  # Hashed identity
    proposal_id: str
    vote: str  # "approve", "reject", "abstain", "veto"
    intensity: float  # For quadratic voting, intensity of preference
    justification: Optional[str] = None
    timestamp: float = 0.0

class SocialOracles:
    """
    Ingests and aggregates external governance signals.
    
    Supports multiple voting mechanisms and stakeholder input channels.
    Respects privacy by hashing identities and aggregating results.
    """
    
    def __init__(self, aggregation_threshold: int = 5):
        self.signals: List[GovernanceSignal] = []
        self.votes: Dict[str, List[StakeholderVote]] = {}  # proposal_id -> votes
        self.aggregation_threshold = aggregation_threshold
        
    def ingest_signal(self, signal: GovernanceSignal):
        """Ingest external governance signal."""
        self.signals.append(signal)
        
        # Sort by priority and timestamp
        self.signals.sort(key=lambda s: (-s.priority, -s.timestamp))
        
        # Keep only recent signals (last 30 days)
        cutoff = time.time() - (30 * 24 * 3600)
        self.signals = [s for s in self.signals if s.timestamp > cutoff]
    
    def cast_vote(self, vote: StakeholderVote):
        """
        Record stakeholder vote with privacy preservation.
        
        Voter ID is hashed; only aggregates are exposed.
        """
        if vote.timestamp == 0.0:
            vote.timestamp = time.time()
        
        if vote.proposal_id not in self.votes:
            self.votes[vote.proposal_id] = []
        
        self.votes[vote.proposal_id].append(vote)
    
    def get_vote_summary(
        self,
        proposal_id: str,
        method: VoteWeight = VoteWeight.QUADRATIC
    ) -> Dict[str, Any]:
        """
        Aggregate votes for a proposal using specified method.
        
        Returns aggregated result respecting privacy (no individual votes exposed).
        """
        if proposal_id not in self.votes:
            return {
                'total_votes': 0,
                'approve': 0.0,
                'reject': 0.0,
                'abstain': 0.0,
                'veto_count': 0,
                'quorum_met': False
            }
        
        votes = self.votes[proposal_id]
        
        # Check for any vetoes (absolute power)
        veto_count = sum(1 for v in votes if v.vote == "veto")
        
        if method == VoteWeight.ONE_PERSON_ONE_VOTE:
            approve = sum(1 for v in votes if v.vote == "approve")
            reject = sum(1 for v in votes if v.vote == "reject")
            abstain = sum(1 for v in votes if v.vote == "abstain")
            total = len(votes)
        
        elif method == VoteWeight.QUADRATIC:
            # Quadratic voting: weight by sqrt(intensity)
            import math
            approve = sum(math.sqrt(v.intensity) for v in votes if v.vote == "approve")
            reject = sum(math.sqrt(v.intensity) for v in votes if v.vote == "reject")
            abstain = sum(math.sqrt(v.intensity) for v in votes if v.vote == "abstain")
            total = approve + reject + abstain
        
        else:  # STAKE_WEIGHTED
            # Linear stake weighting (simplified - would use actual stake in production)
            approve = sum(v.intensity for v in votes if v.vote == "approve")
            reject = sum(v.intensity for v in votes if v.vote == "reject")
            abstain = sum(v.intensity for v in votes if v.vote == "abstain")
            total = approve + reject + abstain
        
        quorum_met = len(votes) >= self.aggregation_threshold
        
        return {
            'total_votes': len(votes),
            'approve': approve,
            'reject': reject,
            'abstain': abstain,
            'veto_count': veto_count,
            'quorum_met': quorum_met,
            'approval_ratio': approve / total if total > 0 else 0.0,
            'method': method.value
        }
    
    def check_veto(self, proposal_id: str) -> bool:
        """Check if proposal has been vetoed by any stakeholder."""
        if proposal_id not in self.votes:
            return False
        
        return any(v.vote == "veto" for v in self.votes[proposal_id])
    
    def get_relevant_signals(
        self,
        policy_id: str,
        signal_types: Optional[List[SignalType]] = None
    ) -> List[GovernanceSignal]:
        """Get signals relevant to a specific policy."""
        relevant = [
            s for s in self.signals
            if policy_id in s.relevant_policies
        ]
        
        if signal_types:
            relevant = [s for s in relevant if s.signal_type in signal_types]
        
        return relevant
    
    def ingest_regulator_update(
        self,
        source: str,
        regulation_name: str,
        requirements: Dict[str, Any],
        effective_date: float,
        affected_policies: List[str]
    ):
        """Convenience method for ingesting regulatory updates."""
        signal = GovernanceSignal(
            signal_id=f"REG_{int(time.time())}",
            signal_type=SignalType.REGULATOR_UPDATE,
            source=source,
            content={
                'regulation_name': regulation_name,
                'requirements': requirements,
                'effective_date': effective_date
            },
            timestamp=time.time(),
            confidence=1.0,  # Regulatory signals are authoritative
            relevant_policies=affected_policies,
            priority=5  # Critical
        )
        
        self.ingest_signal(signal)
    
    def ingest_risk_alert(
        self,
        source: str,
        risk_description: str,
        severity: int,
        affected_policies: List[str],
        mitigation_recommendations: List[str]
    ):
        """Convenience method for risk alerts."""
        signal = GovernanceSignal(
            signal_id=f"RISK_{int(time.time())}",
            signal_type=SignalType.RISK_ALERT,
            source=source,
            content={
                'risk_description': risk_description,
                'severity': severity,
                'mitigation_recommendations': mitigation_recommendations
            },
            timestamp=time.time(),
            confidence=0.8,  # Risk predictions have uncertainty
            relevant_policies=affected_policies,
            priority=min(5, severity)
        )
        
        self.ingest_signal(signal)
Module 4: meta_scheduler.py