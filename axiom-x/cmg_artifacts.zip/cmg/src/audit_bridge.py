"""
Constitutional Meta-Governor: Audit Bridge
Links governance to ProvenanceChain with SEAD attestation.
"""
import hashlib
import json
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

from axiom.testing.integrity_harness import IntegrityAuditLog

@dataclass
class GovernanceReceipt:
    """Cryptographic receipt for governance action."""
    receipt_id: str
    policy_hash: str  # Hash of policy content
    prev_hash: str  # Previous receipt hash (chain)
    timestamp: float
    action: str  # "propose", "approve", "reject", "implement", "rollback"
    actor: str  # Who performed action
    justification: str
    risk_class: str
    signature: str  # HMAC signature
    
    # SEAD attestation
    sead_compliance: Dict[str, bool]  # Which SEAD principles satisfied
    energy_kwh: float
    cost_usd: float
    latency_impact_ms: float
    
    # Rollback information
    rollback_snapshot_id: Optional[str] = None

@dataclass
class SEADAttestation:
    """SEAD (Sociotechnical Ethics and Design) compliance attestation."""
    thermodynamic_realism: bool  # Energy accounted
    pluralism: bool  # Multiple stakeholder input
    privacy_preserving: bool  # Aggregate-only telemetry
    non_coercion: bool  # Opt-in for high-impact changes
    graceful_degradation: bool  # Fails safely
    interpretable_feedback: bool  # Human-readable explanations
    deep_time_evaluation: bool  # Long-term impact considered

class AuditBridge:
    """
    Bridges governance actions to provenance chain with SEAD attestation.
    
    Creates cryptographically-linked receipts for all governance decisions,
    enabling full auditability and compliance verification.
    """
    
    def __init__(
        self,
        audit_log_path: str,
        master_key: bytes = None
    ):
        self.audit_log = IntegrityAuditLog(audit_log_path, master_key)
        self.receipts: List[GovernanceReceipt] = []
        
        # Initialize with genesis receipt
        self._create_genesis_receipt()
    
    def _create_genesis_receipt(self):
        """Create genesis receipt to start the chain."""
        genesis = GovernanceReceipt(
            receipt_id="GENESIS",
            policy_hash="0" * 64,
            prev_hash="0" * 64,
            timestamp=time.time(),
            action="initialize",
            actor="system",
            justification="Constitutional Meta-Governor initialization",
            risk_class="LOW",
            signature="0" * 64,
            sead_compliance={
                'thermodynamic_realism': True,
                'pluralism': True,
                'privacy_preserving': True,
                'non_coercion': True,
                'graceful_degradation': True,
                'interpretable_feedback': True,
                'deep_time_evaluation': True
            },
            energy_kwh=0.0,
            cost_usd=0.0,
            latency_impact_ms=0.0
        )
        
        self.receipts.append(genesis)
    
    def create_receipt(
        self,
        policy_content: Dict[str, Any],
        action: str,
        actor: str,
        justification: str,
        risk_class: str,
        sead_attestation: SEADAttestation,
        energy_kwh: float = 0.0,
        cost_usd: float = 0.0,
        latency_impact_ms: float = 0.0,
        rollback_snapshot_id: Optional[str] = None
    ) -> GovernanceReceipt:
        """
        Create governance receipt with SEAD attestation.
        
        Links to previous receipt to form tamper-evident chain.
        """
        # Compute policy hash
        policy_canonical = json.dumps(policy_content, sort_keys=True).encode('utf-8')
        policy_hash = hashlib.sha256(policy_canonical).hexdigest()
        
        # Get previous receipt hash
        prev_hash = self.receipts[-1].signature if self.receipts else "0" * 64
        
        # Generate receipt ID
        receipt_id = f"RCT_{int(time.time())}_{hashlib.sha256(f'{policy_hash}{prev_hash}'.encode()).hexdigest()[:8]}"
        
        # Create receipt
        receipt = GovernanceReceipt(
            receipt_id=receipt_id,
            policy_hash=policy_hash,
            prev_hash=prev_hash,
            timestamp=time.time(),
            action=action,
            actor=actor,
            justification=justification,
            risk_class=risk_class,
            signature="",  # Will be computed below
            sead_compliance=asdict(sead_attestation),
            energy_kwh=energy_kwh,
            cost_usd=cost_usd,
            latency_impact_ms=latency_impact_ms,
            rollback_snapshot_id=rollback_snapshot_id
        )
        
        # Sign receipt
        receipt.signature = self._sign_receipt(receipt)
        
        # Store in audit log
        self.audit_log.log_operation('governance_action', {
            'receipt_id': receipt.receipt_id,
            'action': receipt.action,
            'policy_hash': receipt.policy_hash,
            'actor': receipt.actor,
            'risk_class': receipt.risk_class,
            'sead_compliance': receipt.sead_compliance
        })
        
        # Add to chain
        self.receipts.append(receipt)
        
        return receipt
    
    def _sign_receipt(self, receipt: GovernanceReceipt) -> str:
        """Compute HMAC signature for receipt."""
        canonical = json.dumps({
            'receipt_id': receipt.receipt_id,
            'policy_hash': receipt.policy_hash,
            'prev_hash': receipt.prev_hash,
            'timestamp': receipt.timestamp,
            'action': receipt.action,
            'actor': receipt.actor
        }, sort_keys=True).encode('utf-8')
        
        import hmac
        return hmac.new(
            self.audit_log.secret_key,
            canonical,
            hashlib.sha256
        ).hexdigest()
    
    def verify_chain(self) -> bool:
        """
        Verify integrity of receipt chain.
        
        Returns: True if chain intact, False if tampered.
        """
        if not self.receipts:
            return True
        
        # Verify each receipt links to previous
        for i in range(1, len(self.receipts)):
            current = self.receipts[i]
            previous = self.receipts[i - 1]
            
            # Verify hash chain
            if current.prev_hash != previous.signature:
                return False
            
            # Verify signature
            expected_sig = self._sign_receipt(current)
            if current.signature != expected_sig:
                return False
        
        # Verify audit log integrity
        return self.audit_log.verify_integrity()
    
    def get_receipt(self, receipt_id: str) -> Optional[GovernanceReceipt]:
        """Retrieve receipt by ID."""
        for receipt in self.receipts:
            if receipt.receipt_id == receipt_id:
                return receipt
        return None
    
    def get_receipts_by_action(self, action: str) -> List[GovernanceReceipt]:
        """Get all receipts for a specific action type."""
        return [r for r in self.receipts if r.action == action]
    
    def get_sead_compliance_report(self) -> Dict[str, Any]:
        """
        Generate SEAD compliance report across all governance actions.
        
        Returns: Aggregate compliance statistics and trends.
        """
        if not self.receipts:
            return {'error': 'No receipts to analyze'}
        
        # Aggregate SEAD compliance
        total_receipts = len(self.receipts)
        
        sead_keys = [
            'thermodynamic_realism',
            'pluralism',
            'privacy_preserving',
            'non_coercion',
            'graceful_degradation',
            'interpretable_feedback',
            'deep_time_evaluation'
        ]
        
        compliance_rates = {
            key: sum(1 for r in self.receipts if r.sead_compliance.get(key, False)) / total_receipts
            for key in sead_keys
        }
        
        # Energy and cost totals
        total_energy_kwh = sum(r.energy_kwh for r in self.receipts)
        total_cost_usd = sum(r.cost_usd for r in self.receipts)
        avg_latency_impact_ms = sum(r.latency_impact_ms for r in self.receipts) / total_receipts
        
        return {
            'total_receipts': total_receipts,
            'compliance_rates': compliance_rates,
            'total_energy_kwh': total_energy_kwh,
            'total_cost_usd': total_cost_usd,
            'avg_latency_impact_ms': avg_latency_impact_ms,
            'chain_integrity': self.verify_chain()
        }
    
    def export_provenance_chain(self, output_path: str):
        """Export complete provenance chain for external audit."""
        chain_data = {
            'version': '1.0',
            'exported_at': time.time(),
            'receipts': [asdict(r) for r in self.receipts],
            'chain_verified': self.verify_chain(),
            'sead_report': self.get_sead_compliance_report()
        }
        
        with open(output_path, 'w') as f:
            json.dump(chain_data, f, indent=2)
Module 6: simlab.py