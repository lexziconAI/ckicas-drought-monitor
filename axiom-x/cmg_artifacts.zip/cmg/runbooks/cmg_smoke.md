# CMG-1 Smoke Test Runbook

**Version**: 1.0  
**Last Updated**: 2025-10-21  
**Audience**: QA engineers, deployment operators  
**Duration**: 15-20 minutes

---

## Overview

This runbook provides pre-flight checks and smoke tests to verify CMG-1 is functioning correctly after deployment or maintenance. All tests must pass before promoting to production.

---

## Prerequisites

- CMG-1 services deployed
- Test credentials configured
- Test data fixtures loaded
- Network connectivity to external services

---

## Pre-Flight Checks

### 1. Service Health

**Expected Duration**: 2 minutes
```bash
#!/bin/bash
# check-services.sh

echo "=== CMG-1 Service Health Check ==="

services=(
  "cmg-scheduler"
  "cmg-audit-bridge"
  "cmg-simlab"
  "cmg-policy-engine"
)

all_healthy=true

for service in "${services[@]}"; do
  status=$(systemctl is-active $service)
  if [ "$status" == "active" ]; then
    echo "✓ $service: RUNNING"
  else
    echo "✗ $service: $status"
    all_healthy=false
  fi
done

if [ "$all_healthy" = true ]; then
  echo "✓ All services healthy"
  exit 0
else
  echo "✗ Some services unhealthy"
  exit 1
fi
```

**Pass Criteria**: All services active  
**Failure Action**: Check logs, restart failed services

---

### 2. Constitutional Hash Verification

**Expected Duration**: 1 minute
```bash
#!/bin/bash
# verify-constitution.sh

echo "=== Constitutional Document Verification ==="

EXPECTED_HASH="a3f7c9e2d5b8..." # Replace with actual hash
CONSTITUTION_PATH="/opt/cmg/governance/CMG_CONSTITUTION.md"

if [ -f "$CONSTITUTION_PATH" ]; then
  ACTUAL_HASH=$(sha256sum $CONSTITUTION_PATH | awk '{print $1}')
  
  if [ "$ACTUAL_HASH" == "$EXPECTED_HASH" ]; then
    echo "✓ Constitution hash verified: $ACTUAL_HASH"
    exit 0
  else
    echo "✗ Constitution hash mismatch!"
    echo "  Expected: $EXPECTED_HASH"
    echo "  Actual:   $ACTUAL_HASH"
    exit 1
  fi
else
  echo "✗ Constitution file not found"
  exit 1
fi
```

**Pass Criteria**: Hash matches expected value  
**Failure Action**: Restore constitution from verified backup

---

### 3. Configuration Validation

**Expected Duration**: 2 minutes
```bash
#!/bin/bash
# validate-config.sh

echo "=== Configuration Validation ==="

configs=(
  "/opt/cmg/configs/cmg_providers.yaml"
  "/opt/cmg/configs/cmg_policies.yaml"
  "/opt/cmg/configs/cmg_scheduler.yaml"
  "/opt/cmg/configs/cmg_dataflow.yaml"
)

all_valid=true

for config in "${configs[@]}"; do
  if [ -f "$config" ]; then
    # Validate YAML syntax
    if python3 -c "import yaml; yaml.safe_load(open('$config'))" 2>/dev/null; then
      echo "✓ $(basename $config): VALID"
    else
      echo "✗ $(basename $config): INVALID YAML"
      all_valid=false
    fi
  else
    echo "✗ $(basename $config): NOT FOUND"
    all_valid=false
  fi
done

if [ "$all_valid" = true ]; then
  exit 0
else
  exit 1
fi
```

**Pass Criteria**: All configs valid YAML  
**Failure Action**: Fix syntax errors, restore from backup

---

## Functional Smoke Tests

### 4. Policy Engine Initialization

**Expected Duration**: 1 minute
```python
#!/usr/bin/env python3
# test_policy_engine.py

import sys
from cmg.src.policy_engine import PolicyEngine

print("=== Policy Engine Initialization Test ===")

try:
    engine = PolicyEngine()
    
    # Verify constitutional constraints loaded
    assert len(engine.constraints) >= 5, "Too few constraints"
    
    constraint_names = [c.name for c in engine.constraints]
    required = [
        "privacy_default_aggregate",
        "kill_switch_accessible",
        "hard_budget_caps",
        "provenance_integrity"
    ]
    
    for name in required:
        assert name in constraint_names, f"Missing constraint: {name}"
    
    print(f"✓ Policy engine initialized with {len(engine.constraints)} constraints")
    sys.exit(0)

except Exception as e:
    print(f"✗ Policy engine initialization failed: {e}")
    sys.exit(1)
```

**Pass Criteria**: Engine initializes with all required constraints  
**Failure Action**: Check constitution file, verify imports

---

### 5. Proposal Submission Test

**Expected Duration**: 2 minutes
```python
#!/usr/bin/env python3
# test_proposal_submission.py

import sys
from cmg.src.policy_engine import PolicyEngine, ChangeType

print("=== Proposal Submission Test ===")

try:
    engine = PolicyEngine()
    
    # Submit valid LOW-risk proposal
    proposal = engine.propose_policy(
        author="smoke_test",
        rationale="Smoke test proposal",
        affected_modules=["test_module"],
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={'aggregate_only': True},
        expected_benefits={'test': 1.0},
        risks=["None - test only"],
        test_plan={'scenarios': ['baseline']},
        references=["10.1145/test"]
    )
    
    assert proposal is not None, "Proposal is None"
    assert proposal.id.startswith("PROP_"), "Invalid proposal ID"
    assert proposal.risk_class is not None, "Risk class not assigned"
    
    print(f"✓ Proposal submitted: {proposal.id}")
    print(f"  Risk class: {proposal.risk_class.value}")
    sys.exit(0)

except Exception as e:
    print(f"✗ Proposal submission failed: {e}")
    sys.exit(1)
```

**Pass Criteria**: Proposal created with valid ID and risk class  
**Failure Action**: Check policy engine logs, verify database connectivity

---

### 6. Constitutional Validation Test

**Expected Duration**: 2 minutes
```python
#!/usr/bin/env python3
# test_constitutional_validation.py

import sys
from cmg.src.policy_engine import PolicyEngine, ChangeType, ConstitutionalViolation

print("=== Constitutional Validation Test ===")

engine = PolicyEngine()

# Test 1: Privacy violation should be blocked
print("Test 1: Privacy violation detection...")
try:
    proposal = engine.propose_policy(
        author="test",
        rationale="Violate privacy",
        affected_modules=["telemetry"],
        change_type=ChangeType.TELEMETRY_RESOLUTION,
        constraints={'aggregate_only': False},  # VIOLATION
        expected_benefits={},
        risks=[],
        test_plan={'scenarios': ['baseline']},
        references=[]
    )
    print("✗ Privacy violation NOT detected")
    sys.exit(1)
except ConstitutionalViolation:
    print("✓ Privacy violation correctly blocked")

# Test 2: Kill-switch modification should be blocked
print("Test 2: Kill-switch protection...")
try:
    proposal = engine.propose_policy(
        author="test",
        rationale="Modify kill switch",
        affected_modules=["kill_switch"],  # FORBIDDEN
        change_type=ChangeType.OPERATIONAL_PARAMETER,
        constraints={},
        expected_benefits={},
        risks=[],
        test_plan={'scenarios': ['baseline']},
        references=[]
    )
    print("✗ Kill-switch modification NOT blocked")
    sys.exit(1)
except ConstitutionalViolation:
    print("✓ Kill-switch modification correctly blocked")

print("✓ All constitutional validation tests passed")
sys.exit(0)
```

**Pass Criteria**: Both violations correctly detected and blocked  
**Failure Action**: Review policy engine validation logic

---

### 7. Voting and Quorum Test

**Expected Duration**: 2 minutes
```python
#!/usr/bin/env python3
# test_voting.py

import sys
from cmg.src.social_oracles import SocialOracles, StakeholderVote, VoteWeight

print("=== Voting and Quorum Test ===")

try:
    oracles = SocialOracles(aggregation_threshold=3)
    
    # Cast votes
    for i in range(5):
        oracles.cast_vote(StakeholderVote(
            voter_id=f"test_voter_{i}",
            proposal_id="test_proposal",
            vote="approve" if i < 4 else "reject",
            intensity=1.0
        ))
    
    # Get summary
    summary = oracles.get_vote_summary("test_proposal", VoteWeight.QUADRATIC)
    
    assert summary['total_votes'] == 5, "Vote count mismatch"
    assert summary['quorum_met'] == True, "Quorum not met"
    assert summary['approve'] > summary['reject'], "Vote tally incorrect"
    
    print(f"✓ Voting system functional")
    print(f"  Total votes: {summary['total_votes']}")
    print(f"  Approval ratio: {summary['approval_ratio']:.2f}")
    sys.exit(0)

except Exception as e:
    print(f"✗ Voting test failed: {e}")
    sys.exit(1)
```

**Pass Criteria**: Votes counted correctly, quorum calculated  
**Failure Action**: Check social oracles module, verify vote aggregation

---

### 8. Simulation Sandbox Test

**Expected Duration**: 3 minutes
```python
#!/usr/bin/env python3
# test_simulation.py

import sys
from cmg.src.simlab import SimulationLab, SimulationConfig, SimulationScenario

print("=== Simulation Sandbox Test ===")

try:
    baseline_config = {
        'performance': {
            'base_latency_ms': 100,
            'latency_multiplier': 1.0
        }
    }
    
    lab = SimulationLab(baseline_config)
    
    policy_changes = {
        'performance': {
            'base_latency_ms': 90
        }
    }
    
    sim_config = SimulationConfig(
        scenarios=[SimulationScenario.BASELINE, SimulationScenario.PESSIMISTIC],
        duration_seconds=60,
        sample_size=100,  # Small for smoke test
        chaos_enabled=False
    )
    
    reports = lab.simulate_impact(policy_changes, sim_config)
    
    assert len(reports) == 2, "Wrong number of reports"
    assert reports[0].scenario == "baseline", "Scenario mismatch"
    assert reports[0].latency_delta_ms < 0, "Latency should improve"
    
    print(f"✓ Simulation completed")
    print(f"  Scenarios run: {len(reports)}")
    print(f"  Baseline latency delta: {reports[0].latency_delta_ms:.1f}ms")
    sys.exit(0)

except Exception as e:
    print(f"✗ Simulation test failed: {e}")
    sys.exit(1)
```

**Pass Criteria**: Simulation completes and produces reports  
**Failure Action**: Check simlab service, verify resource availability

---

### 9. Audit Chain Integrity Test

**Expected Duration**: 2 minutes
```python
#!/usr/bin/env python3
# test_audit_chain.py

import sys
import tempfile
from cmg.src.audit_bridge import AuditBridge, SEADAttestation

print("=== Audit Chain Integrity Test ===")

try:
    with tempfile.TemporaryDirectory() as tmpdir:
        bridge = AuditBridge(f"{tmpdir}/test_audit.log")
        
        # Create test receipts
        attestation = SEADAttestation(
            thermodynamic_realism=True,
            pluralism=True,
            privacy_preserving=True,
            non_coercion=True,
            graceful_degradation=True,
            interpretable_feedback=True,
            deep_time_evaluation=True
        )
        
        for i in range(5):
            bridge.create_receipt(
                policy_content={'test': i},
                action="test",
                actor="smoke_test",
                justification=f"Test receipt {i}",
                risk_class="LOW",
                sead_attestation=attestation
            )
        
        # Verify chain
        integrity_ok = bridge.verify_chain()
        assert integrity_ok, "Chain integrity check failed"
        
        # Verify receipt count (genesis + 5 test)
        assert len(bridge.receipts) == 6, "Receipt count mismatch"
        
        print(f"✓ Audit chain verified")
        print(f"  Receipts: {len(bridge.receipts)}")
        sys.exit(0)

except Exception as e:
    print(f"✗ Audit chain test failed: {e}")
    sys.exit(1)
```

**Pass Criteria**: Chain integrity verified, all receipts linked  
**Failure Action**: Check audit bridge module, verify cryptography

---

### 10. Rollback Capability Test

**Expected Duration**: 2 minutes
```python
#!/usr/bin/env python3
# test_rollback.py

import sys
import tempfile
from cmg.src.policy_store import PolicyStore

print("=== Rollback Capability Test ===")

try:
    with tempfile.TemporaryDirectory() as tmpdir:
        store = PolicyStore(tmpdir)
        
        # Create initial version with snapshot
        v1 = store.store_policy_version(
            policy_id="test_policy",
            content={'value': 1},
            author="test",
            change_summary="V1",
            create_snapshot=True
        )
        
        snapshot_id = v1.rollback_snapshot_id
        assert snapshot_id is not None, "Snapshot not created"
        
        # Create second version
        v2 = store.store_policy_version(
            policy_id="test_policy",
            content={'value': 2},
            author="test",
            change_summary="V2"
        )
        
        # Verify current is V2
        current = store.current_versions["test_policy"]
        assert current.content['value'] == 2, "V2 not current"
        
        # Rollback to snapshot
        success = store.rollback(snapshot_id)
        assert success, "Rollback failed"
        
        # Verify rolled back to V1
        current = store.current_versions["test_policy"]
        assert current.content['value'] == 1, "Rollback did not restore V1"
        
        print(f"✓ Rollback capability verified")
        sys.exit(0)

except Exception as e:
    print(f"✗ Rollback test failed: {e}")
    sys.exit(1)
```

**Pass Criteria**: Rollback successfully restores previous state  
**Failure Action**: Check policy store, verify snapshot mechanism

---

## Audit Export Test

### 11. Generate Audit Export

**Expected Duration**: 2 minutes
```bash
#!/bin/bash
# test_audit_export.sh

echo "=== Audit Export Test ==="

OUTPUT_DIR="/tmp/cmg-audit-export-$(date +%Y%m%d-%H%M%S)"
mkdir -p $OUTPUT_DIR

# Generate export
cmg-cli audit export --output=$OUTPUT_DIR/provenance-chain.json

if [ -f "$OUTPUT_DIR/provenance-chain.json" ]; then
  # Verify JSON is valid
  if python3 -c "import json; json.load(open('$OUTPUT_DIR/provenance-chain.json'))" 2>/dev/null; then
    echo "✓ Audit export generated and valid"
    
    # Check for required fields
    RECEIPTS=$(python3 -c "import json; print(len(json.load(open('$OUTPUT_DIR/provenance-chain.json'))['receipts']))")
    echo "  Receipts exported: $RECEIPTS"
    
    if [ "$RECEIPTS" -gt 0 ]; then
      exit 0
    else
      echo "✗ No receipts in export"
      exit 1
    fi
  else
    echo "✗ Invalid JSON in export"
    exit 1
  fi
else
  echo "✗ Export file not created"
  exit 1
fi
```

**Pass Criteria**: Export generated with valid JSON and receipts  
**Failure Action**: Check audit bridge, verify file permissions

---

## Smoke Test Suite Runner

### Complete Smoke Test

**Expected Duration**: 15-20 minutes
```bash
#!/bin/bash
# run-smoke-tests.sh

echo "======================================"
echo "  CMG-1 SMOKE TEST SUITE"
echo "======================================"
echo ""

TESTS=(
  "check-services.sh"
  "verify-constitution.sh"
  "validate-config.sh"
  "test_policy_engine.py"
  "test_proposal_submission.py"
  "test_constitutional_validation.py"
  "test_voting.py"
  "test_simulation.py"
  "test_audit_chain.py"
  "test_rollback.py"
  "test_audit_export.sh"
)

PASSED=0
FAILED=0
RESULTS=()

for test in "${TESTS[@]}"; do
  echo "Running: $test"
  
  if ./$test; then
    PASSED=$((PASSED + 1))
    RESULTS+=("✓ $test")
  else
    FAILED=$((FAILED + 1))
    RESULTS+=("✗ $test")
  fi
  
  echo ""
done

echo "======================================"
echo "  SMOKE TEST RESULTS"
echo "======================================"
for result in "${RESULTS[@]}"; do
  echo "$result"
done
echo ""
echo "Passed: $PASSED / $((PASSED + FAILED))"
echo "Failed: $FAILED / $((PASSED + FAILED))"
echo ""

if [ $FAILED -eq 0 ]; then
  echo "✓ ALL SMOKE TESTS PASSED"
  exit 0
else
  echo "✗ SOME TESTS FAILED - DO NOT DEPLOY"
  exit 1
fi
```

**Pass Criteria**: All 11 tests pass  
**Failure Action**: Investigate failed tests before deployment

---

## Post-Smoke Test Actions

### On Success

1. **Record Results**
```bash
   ./run-smoke-tests.sh > smoke-test-$(date +%Y%m%d-%H%M%S).log 2>&1
```

2. **Tag Release**
```bash
   git tag -a v1.0.0-smoke-passed -m "Smoke tests passed $(date)"
   git push origin v1.0.0-smoke-passed
```

3. **Promote to Production**
   - Update deployment manifest
   - Schedule production deployment
   - Notify operations team

### On Failure

1. **Preserve Evidence**
```bash
   # Capture logs
   mkdir -p /var/log/cmg/smoke-failures/$(date +%Y%m%d-%H%M%S)
   cp /var/log/cmg/*.log /var/log/cmg/smoke-failures/$(date +%Y%m%d-%H%M%S)/
```

2. **Rollback Deployment**
```bash
   # Revert to previous version
   kubectl rollback deployment/cmg-stack
```

3. **Create Incident Report**
   - Document which tests failed
   - Capture error messages and logs
   - Assign to development team
   - Set priority based on failure severity

---

**End of Smoke Test Runbook**
Should I continue with the telemetry schema, evaluation plan, and decision brief?RetryRDyes pleaseOrchestrated final design artifacts for comprehensive package completion.The user wants me to continue with:

Telemetry schema (cmg_schema.json)
Evaluation plan (cmg_eval_plan.md)
Decision brief (cmg_brief.md)

Let me create these final artifacts to complete the CMG-1 design package.CMG-1 DESIGN ARTIFACTS — CONTINUED (PART 8)

PART 8: TELEMETRY SCHEMA AND EVALUATION
Telemetry Schema: cmg_schema.json