# CMG-1 Operations Runbook

**Version**: 1.0  
**Last Updated**: 2025-10-21  
**Audience**: System operators, governance administrators

---

## Overview

This runbook covers daily operations, proposal lifecycle management, quorum configuration, manual ratification procedures, and rollback operations for the Constitutional Meta-Governor (CMG-1).

---

## Daily Operations

### Morning Checks (Start of Business Day)

**Duration**: 15 minutes  
**Frequency**: Daily

1. **Verify System Health**
```bash
   # Check CMG services status
   systemctl status cmg-scheduler
   systemctl status cmg-audit-bridge
   systemctl status cmg-simlab
   
   # Expected: All services "active (running)"
```

2. **Check Chain Integrity**
```bash
   # Run integrity verification
   cmg-cli verify-chain
   
   # Expected output: "Chain integrity: VERIFIED"
```

3. **Review Overnight Activity**
```bash
   # List proposals submitted in last 24 hours
   cmg-cli list-proposals --since="24h"
   
   # Check for HIGH-risk proposals requiring attention
   cmg-cli list-proposals --risk=HIGH --state=pending
```

4. **Check Resource Budgets**
```bash
   # Review energy and cost usage
   cmg-cli resource-status
   
   # Expected: Energy within 80% of soft limit, <100% of hard limit
```

5. **Review Failed Background Tasks**
```bash
   # Check task log for failures
   tail -n 100 /var/log/cmg/background-tasks.log | grep ERROR
```

**Escalation**: If chain integrity fails or >3 HIGH-risk proposals pending, notify governance team immediately.

---

## Proposal Lifecycle Management

### Submitting a Proposal

**Prerequisites**: 
- Proposal author credentials
- Policy impact analysis completed
- Simulation results available

**Procedure**:

1. **Prepare Proposal Document**
```yaml
   # proposal.yaml
   author: "team_name"
   rationale: "Clear justification with references"
   affected_modules:
     - "module_name"
   change_type: "THRESHOLD_ADJUSTMENT"
   constraints:
     aggregate_only: true
   expected_benefits:
     latency_reduction_ms: 20.0
   risks:
     - "Description of potential risk"
   test_plan:
     scenarios:
       - "baseline"
       - "pessimistic"
   references:
     - "DOI:10.1145/example"
```

2. **Validate Proposal**
```bash
   # Validate against constitutional constraints
   cmg-cli validate-proposal proposal.yaml
   
   # Expected: "✓ Constitutional validation passed"
```

3. **Run Simulations**
```bash
   # Execute required simulations
   cmg-cli simulate proposal.yaml --scenarios=all
   
   # Review results in output/simulation-report.json
```

4. **Submit Proposal**
```bash
   # Submit to governance workflow
   cmg-cli submit-proposal proposal.yaml
   
   # Note returned proposal ID for tracking
```

5. **Monitor Workflow**
```bash
   # Check proposal status
   cmg-cli status --proposal-id=PROP_abc123
```

---

### Monitoring Active Proposals

**Frequency**: Every 4 hours during deliberation/voting

1. **List Active Proposals**
```bash
   cmg-cli list-proposals --state=active
```

2. **Check Vote Progress**
```bash
   cmg-cli vote-summary --proposal-id=PROP_abc123
```

3. **Review Stakeholder Feedback**
```bash
   # Check for veto flags or concerns
   cmg-cli list-signals --proposal-id=PROP_abc123 --type=veto
```

4. **Escalation Triggers**
   - Veto received → Notify proposal author and governance team
   - Quorum not reached 48h before deadline → Send reminder to stakeholders
   - Simulation failures detected → Halt progression, investigate

---

### Manual Ratification (HIGH-Risk Proposals)

**Authority**: Chief Security Officer (CSO) or Chief Privacy Officer (CPO)  
**Time Limit**: 72 hours from voting completion

**Procedure**:

1. **Retrieve Proposal Details**
```bash
   cmg-cli get-proposal PROP_abc123 --full-details > proposal-review.json
```

2. **Review Documentation**
   - Constitutional compliance check
   - Simulation results (all scenarios)
   - Stakeholder vote summary
   - Risk assessment report
   - Rollback plan

3. **Convene Review Meeting** (if needed)
   - Attendees: CSO, CPO, proposal author, governance team
   - Duration: 30-60 minutes
   - Document decision rationale

4. **Record Ratification Decision**
```bash
   # Approve
   cmg-cli human-ratify PROP_abc123 --decision=approve \
     --approver=cso_name \
     --justification="Detailed rationale here"
   
   # Or reject
   cmg-cli human-ratify PROP_abc123 --decision=reject \
     --approver=cso_name \
     --justification="Reason for rejection"
```

5. **Notification**
   - System automatically notifies stakeholders
   - Generate ratification receipt
   - Update governance dashboard

---

## Quorum Settings

### Viewing Current Settings
```bash
cmg-cli config get deliberation.quorum_requirements
```

**Default Values**:
- LOW risk: 3 votes
- MEDIUM risk: 5 votes  
- HIGH risk: 10 votes

### Modifying Quorum (Requires Admin)

**Note**: Quorum changes are themselves governance decisions requiring approval.

1. **Propose Quorum Change**
```bash
   cmg-cli propose-meta-change \
     --setting=deliberation.quorum_requirements.high_risk \
     --current-value=10 \
     --proposed-value=15 \
     --rationale="Increased stakeholder base requires higher quorum"
```

2. **Follow Standard Governance Process**
   - Meta-changes follow same workflow as policy proposals
   - Require HIGH-risk approval process

---

## Rollback Procedures

### Emergency Rollback (Immediate)

**Trigger Conditions**:
- Privacy violation detected
- Chain-of-trust integrity failure
- Error rate >5% for sustained 5 minutes
- P95 latency exceeds hard limit

**Procedure**:

1. **Identify Problematic Policy**
```bash
   # List recent policy changes
   cmg-cli history --last=5
```

2. **Locate Rollback Snapshot**
```bash
   # Get snapshot ID from policy version
   cmg-cli get-snapshot --policy-id=test_policy --version=VER_xyz789
```

3. **Execute Rollback**
```bash
   # Initiate rollback (requires elevated privileges)
   sudo cmg-cli rollback SNAP_abc123 --emergency
   
   # Confirm rollback
   # WARNING: This action is immediate and irreversible
```

4. **Verify System Stability**
```bash
   # Check key metrics
   cmg-cli health-check --verbose
   
   # Verify chain integrity post-rollback
   cmg-cli verify-chain
```

5. **Post-Mortem**
   - Create incident report within 48 hours
   - Document root cause
   - Propose preventive measures

---

### Scheduled Rollback (Within 7-Day Window)

**Use Case**: Undisclosed negative impacts discovered post-implementation

**Procedure**:

1. **Request Rollback**
```bash
   cmg-cli request-rollback \
     --policy-id=test_policy \
     --snapshot-id=SNAP_abc123 \
     --requestor=stakeholder_id \
     --justification="Detailed explanation of issue"
```

2. **Rollback Review** (24-hour SLA)
   - Meta-scheduler reviews request
   - Validates justification
   - Checks for dependencies

3. **Stakeholder Notification**
   - All affected stakeholders notified
   - 24-hour comment period (can be expedited for critical issues)

4. **Execute Rollback**
```bash
   # After review approval
   cmg-cli execute-rollback SNAP_abc123
```

5. **Post-Rollback Actions**
   - Generate rollback receipt
   - Update audit log
   - Notify stakeholders of completion

---

## Configuration Management

### Viewing Active Configuration
```bash
# View all CMG configuration
cmg-cli config show

# View specific section
cmg-cli config show deliberation
```

### Backup Configuration

**Frequency**: Before any configuration change
```bash
# Create backup
cmg-cli config backup --output=/var/backups/cmg/config-$(date +%Y%m%d).yaml
```

### Restore Configuration
```bash
# Restore from backup
sudo cmg-cli config restore /var/backups/cmg/config-20251021.yaml
```

---

## Troubleshooting

### Proposal Stuck in Deliberation

**Symptoms**: Proposal past max deliberation time, not advancing

**Resolution**:
```bash
# Check scheduler status
cmg-cli scheduler status

# Manually advance if stuck
sudo cmg-cli scheduler advance --proposal-id=PROP_abc123

# Check logs
tail -f /var/log/cmg/scheduler.log
```

### Vote Summary Not Updating

**Symptoms**: Vote counts not reflecting recent votes

**Resolution**:
```bash
# Refresh vote cache
cmg-cli votes refresh --proposal-id=PROP_abc123

# Verify vote database integrity
cmg-cli votes verify
```

### Simulation Failures

**Symptoms**: Simulations timing out or producing errors

**Resolution**:
```bash
# Check simulation service
systemctl status cmg-simlab

# Review simulation logs
tail -n 100 /var/log/cmg/simlab.log

# Retry simulation with verbose logging
cmg-cli simulate proposal.yaml --verbose --debug
```

### Chain Integrity Failure

**Symptoms**: `verify-chain` returns FAILED

**Resolution**:
```bash
# Identify break point
cmg-cli chain-audit --detailed

# If corruption detected, DO NOT PROCEED
# Immediately notify security team
# Preserve evidence for forensic analysis
# Do not attempt repair without security team approval
```

---

## Monitoring and Alerts

### Key Metrics to Monitor

| Metric | Alert Threshold | Action |
|--------|----------------|--------|
| Chain integrity | FAILED | Immediate escalation |
| Energy usage | >90% of hard limit | Review and reduce |
| Proposal queue depth | >15 active | Increase review capacity |
| Vote participation rate | <50% | Stakeholder engagement campaign |
| Simulation failure rate | >10% | Investigate simulation service |
| Rollback frequency | >2 per week | Review approval process |

### Alert Destinations

- **Critical**: PagerDuty + Email + Slack #cmg-critical
- **High**: Email + Slack #cmg-alerts
- **Medium**: Slack #cmg-monitoring
- **Low**: Dashboard only

---

## Maintenance Windows

### Weekly Maintenance

**Schedule**: Sunday 02:00-04:00 UTC  
**Duration**: 2 hours  
**Impact**: No new proposals accepted during window

**Tasks**:
- Snapshot cleanup (retain last 10)
- Log rotation and archival
- Database optimization
- Configuration backup
- Health checks

### Quarterly Maintenance

**Schedule**: First Sunday of quarter, 00:00-06:00 UTC  
**Duration**: 6 hours  
**Impact**: Read-only mode

**Tasks**:
- Major version updates
- Security patches
- Performance optimization
- Audit export
- Constitutional review preparation

---

## Emergency Contacts

| Role | Contact | Availability |
|------|---------|--------------|
| On-Call Engineer | oncall@example.com | 24/7 |
| Governance Lead | governance@example.com | Business hours |
| CSO | cso@example.com | Escalation only |
| CPO | cpo@example.com | Escalation only |

---

## Change Log

| Date | Version | Changes | Author |
|------|---------|---------|--------|
| 2025-10-21 | 1.0 | Initial runbook | CMG Design Team |

---

**End of Operations Runbook**
Runbook 2: cmg_smoke.md